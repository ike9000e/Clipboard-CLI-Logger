#include "vcm_entrypoint.h"
#include <assert.h>
#include <memory>
#include "hxdw_utils.h"
#include "hxdw_checksum.h"

// Linker:
//     /IGNORE:4075 - LNK4075: ignoring '/EDITANDCONTINUE' due to '/OPT:ICF' specification
//
std::string VcmConvToSingleLine( const char* inp, int mode2 )
{
	assert( mode2 >= 1 );
	std::string outp3 = inp;
	if( mode2 == 1 ){
		outp3 = hxdw_StrReplace( outp3, "\r\n", "\\n" );
		outp3 = hxdw_StrReplace( outp3, "\r", "\\r" );
		outp3 = hxdw_StrReplace( outp3, "\n", "\\n" );
	}else if( mode2 == 2 ){
		outp3 = hxdw_StrReplace( outp3, "\r", "<0D>" );
		outp3 = hxdw_StrReplace( outp3, "\n", "<0A>" );
	}else if( mode2 == 3 ){
		outp3 = hxdw_StrReplace( outp3, "\r\n", "\x20" );
		outp3 = hxdw_StrReplace( outp3, "\r", "\x20" );
		outp3 = hxdw_StrReplace( outp3, "\n", "\x20" );
	}else if( mode2 == 4 ){
		outp3 = hxdw_StrReplace( outp3, "\r", "" );
		outp3 = hxdw_StrReplace( outp3, "\n", "" );
	}else{
		assert(0);
	}
	return outp3;
}

void VcmFputsWithAffix( const char* inp, const std::string& prefix2, const std::string& suffix2, const VcmConfig& dto3 )
{
	std::string outp4;
	if( !prefix2.empty() ){
		//std::fputs( prefix2.c_str(), stdout );
		outp4 += prefix2;
	}
	if( dto3.nLogLevel >= 8 ){
		std::fputs( hxdw_StrPrintf("VCM: CB Size: %d\n", { (int)std::strlen(inp),}).c_str(), stderr );
	}
	//std::fputs( inp, stdout );
	outp4 += inp;

	if( !suffix2.empty() ){
		//std::fputs( suffix2.c_str(), stdout );
		outp4 += suffix2;
		if( !hxdw_EndsWith( suffix2.c_str(), -1, "\n", -1, "") ){
			//std::fputs( "\n", stdout );
			outp4 += "\n";
		}
	}else{
		if( !hxdw_EndsWith( inp, -1, "\n", -1, "") ){
			//std::fputs( "\n", stdout );
			outp4 += "\n";
		}
	}
	if( !dto3.anOutFileName.empty() ){
		hxdw_PutFileContents(
			dto3.anOutFileName.c_str(),
			outp4.c_str(),
			-1,
			"a" );
	}else{
		std::fputs( outp4.c_str(), stdout );
	}
}
int main( int argc, const char*const* argv )
{
	std::fputs( hxdw_StrPrintf("VCM: Build: %s\n", { hxdw_GetDateAtCompileTime(""),}).c_str(), stderr );
	std::fputs( hxdw_StrPrintf("     (Use ctrl+c to terinate.)\n", {}).c_str(), stderr );
	std::fputs( "\n", stderr );
	VcmConfig sAppDTO;
	sAppDTO.bStartHidden     = 1L;
	sAppDTO.srWindowTitle    = "CB Monitor Helper Window (VCM) [wbqnXc]";
	sAppDTO.bWndTitleAddDate = 1L;
	sAppDTO.bTrayIcon        = 0L;
	for( int ii2=1; ii2 < argc; ii2++ ){
		const std::string arg0 = argv[ii2];
		const std::string arg1 = ( ii2+1 < argc ? argv[ii2+1] : "");
		const int nArgAsInt = atoi( arg1.empty() || !isdigit(arg1[0]) ? "1" : arg1.c_str() );
		if( arg0 == "-bStartHidden" ){
			sAppDTO.bStartHidden = !!nArgAsInt;
		}else if( arg0 == "-bTrayIcon" ){
			sAppDTO.bTrayIcon = !!nArgAsInt;
		}else if( arg0 == "-bWndTitleAddDate" ){
			sAppDTO.bWndTitleAddDate = !!nArgAsInt;
		}else if( arg0 == "-anWindowIconFile" ){
			// eg. "./mainicon.ico"
			sAppDTO.srWindowIconFile = { 1L, arg1.c_str(),};
		}else if( arg0 == "-nWindowIconId" ){
			// eg. 32516 (IDI_INFORMATION)
			sAppDTO.nWindowIconId = { 1L, (LPCTSTR)(size_t)nArgAsInt,};
		}else if( arg0 == "-bSkipDupes" ){
			sAppDTO.bSkipDupes = !!nArgAsInt;
		}else if( arg0 == "-nLogLevel" ){
			sAppDTO.nLogLevel = nArgAsInt;
		}else if( arg0 == "-anPrefix" ){
			sAppDTO.anPrefix = arg1;
		}else if( arg0 == "-anSuffix" ){
			sAppDTO.anSuffix = arg1;
		}else if( arg0 == "-bForceSingleLine" ){
			sAppDTO.bForceSingleLine = nArgAsInt;
		}else if( arg0 == "-nMaxCaptures" ){
			assert( nArgAsInt >= 0 );
			sAppDTO.nMaxCaptures = nArgAsInt;
		}else if( arg0 == "-anOutFileName" || arg0 == "-ofn" ){
			sAppDTO.anOutFileName = arg1;
		}
	}
	if( !sAppDTO.anOutFileName.empty() ){
		hxdw_PutFileContents( sAppDTO.anOutFileName.c_str(), "", -1, "");
	}
	sAppDTO.bCBMonitor = 1L;
	sAppDTO.bCBNoMsg = 1L;
	sAppDTO.uClrWindow.first = 1L;
	std::string srLastCBDigest;
	uint64_t uCntCaptured = 0;
	HxdwAuxMainWindow* ti3 = nullptr;
	sAppDTO.calbClipboardChanged2 = [&]( const HxdwCB2* inp )->bool{
		if( sAppDTO.bSkipDupes ){
			HxdwMd5 chk2;
			chk2.update2( reinterpret_cast<const uint8_t*>( inp->srCBText2.c_str() ), static_cast<uint32_t>( inp->srCBText2.size() ) );
			const std::string srDgst = chk2.finalize2().getHexDigest();
			if( srLastCBDigest == srDgst && !srLastCBDigest.empty() ){
				if( sAppDTO.nLogLevel >= 8 ){
					std::fputs("VCM: Duplicated CB contents detected, skipping.\n", stderr );
				}
				return 1L;
			}
			srLastCBDigest = srDgst;
		}
		std::string outp2 = inp->srCBText2;
		if( sAppDTO.bForceSingleLine ){
			outp2 = VcmConvToSingleLine( outp2.c_str(), sAppDTO.bForceSingleLine );
		}
		VcmFputsWithAffix( outp2.c_str(), sAppDTO.anPrefix, sAppDTO.anSuffix, sAppDTO );
		if( uCntCaptured+1 >= sAppDTO.nMaxCaptures && sAppDTO.nMaxCaptures ){
			assert( ti3 );
			ti3->closeWindow();
		}
		uCntCaptured += 1;
		return 1L;
	};
	HxdwAuxMainWindow ti2( sAppDTO );
	ti3 = &ti2;
	ti2.exec2();
	if( sAppDTO.nLogLevel >= 8 ){
		std::fputs( hxdw_StrPrintf("VCM: Exiting...\n", {}).c_str(), stderr );
	}
	return 0;
}
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	std::vector<std::string> argv2; std::vector<const char*> argv3;
	argv3 = hxdw_GetCommandLine3( &argv2 );
	assert( argv3.size() < 65536 );
	int rslt = main( (int)argv3.size(), &argv3[0] );
	return rslt;
}
