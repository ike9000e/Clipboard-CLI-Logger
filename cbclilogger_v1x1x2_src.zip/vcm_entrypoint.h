#pragma once
//#include <windows.h>
#include <vector>
#include <string>
#include "hxdw_aux_window.h"

struct VcmConfig : HxdwAWConfig {

	bool bSkipDupes = 0L;
	int nLogLevel = 8;
	std::string anPrefix, anSuffix;
	int bForceSingleLine = 0;
	uint64_t nMaxCaptures = 0;  // Max CB captures before auto exit. 0 means disabled.
	std::string anOutFileName;
};
