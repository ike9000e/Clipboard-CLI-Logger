#pragma once
#include <windows.h>
#include <shellapi.h>   //NOTIFYICONDATA
#include <vector>
#include <string>
#include <functional>
#include <algorithm>

struct HxdwMsg2; struct HxdwCB2; struct HxdwWC2;
using HxdwResult2 = std::pair<bool,LRESULT>;

/// Config for HxdwAuxMainWindow.
struct HxdwAWConfig{
	bool          bConfirmQuit = 1L;
	void*         user2;
	bool          bKeyQToQuit = 1L, bKeyXToQuit = 0L;
	bool          bIgnoreAltF4 = 0L;
	std::pair<bool,uint32_t> uClrWindow = { 0L, 0x00820000,}; //format: 0x00BBGGRR
	std::string   srWindowTitle;
	bool          bWndTitleAddDate = 1L;
	//
	bool          bTrayIcon = 1L;
	bool          bKeyEscToTray = 1L, bKeySpaceToTray = 1L, bStartHidden = 0L;
	//
	std::pair<bool,LPCTSTR>     nWindowIconId = { 0L, IDI_INFORMATION,}; // IDI_INFORMATION(32516)/IDI_ASTERISK(32516)/IDI_EXCLAMATION/IDI_WARNING(32515)
	std::pair<bool,std::string> srWindowIconFile = { 0L, "",};
	std::pair<bool,HICON>       hWindowIcon = { 0L, 0,};
	//
	std::function<std::string(void* user2)>       calbGetWindowTitle = nullptr;
	std::function<HxdwResult2( const HxdwMsg2* )> calbOnWndProc2 = nullptr;
	std::function<bool(const HxdwWC2*)>           calbOnWndCreate = nullptr;
	//
	bool bCBMonitor = 0L;
	std::vector<UINT> aCBFormats = {}; //eg. CF_TEXT. empty defaults to CF_TEXT only.
	std::function<bool(const HxdwCB2* inp)> calbClipboardChanged2 = nullptr;
	bool bCBAutoGetText = 1L;
	bool bCBNoMsg = 0L;
};

struct HxdwMsg2{
	HxdwMsg2() = delete;
	HWND   hWnd;
	UINT   msg2;
	WPARAM wParam;
	LPARAM lParam;
	void*  user2;
};
struct HxdwCB2{
	uint32_t     uCBFormat2;  /// Eg. CF_TEXT.
	std::string  srCBText2;   /// requires \ref HxdwAWConfig::bCBAutoGetText set.
	uint64_t     nIndex2;
};

struct HxdwWC2{
	HWND  hWnd;
	void* user2;
};

/// Main window as a class that also shows a tray icon.
struct HxdwAuxMainWindow {
	;           HxdwAuxMainWindow( const HxdwAWConfig& dto2 );
	;           ~HxdwAuxMainWindow();
	int         exec2();
	bool        closeWindow();
	//setTimeout2()
private:
	auto                 getAppTitleText() -> const char*;
	friend auto CALLBACK WndProc2( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam ) -> LRESULT;
	auto                 WndProc3( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam ) -> LRESULT;
	ATOM                 registerHlprWndClass( HINSTANCE hInstance );
	bool                 initInstance( HINSTANCE hInstance, int nCmdShow );
	void                 initializeTrayIcon();
	void                 toggleWindowToTrayVisibility( int bShow2 );
	bool                 showMessage2( const char* szMsg, const char* flags2, size_t );
private:
	enum : int{
		mWMTrayAnyMessageId = WM_USER + 4136, //WM_USER=1024
		mWMDestroyLv2Id     = WM_USER + 4137,
	};
	struct SCBView{
		HWND hwCbvNext = 0;
		bool bInited2 = 0;
	};
	HxdwAWConfig          mAppDTO;
	HWND                  mHwnd = 0;
	NOTIFYICONDATA        mNid;
	bool                  mIsInTray = 0L, mIsMbxActive = 0L;
	DWORD                 mDwMainThreadId = 0;
	SCBView               mCbv2;
	HICON                 mLoadedFileIcom = 0;
	uint64_t              mCBIndex2 = 0;
};
