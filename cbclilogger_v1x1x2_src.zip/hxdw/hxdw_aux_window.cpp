#include "hxdw_aux_window.h"
#include <assert.h>
#include <memory>
#include "hxdw_utils.h"

// Linker:
//     /IGNORE:4075 - LNK4075: ignoring '/EDITANDCONTINUE' due to '/OPT:ICF' specification
//

#ifdef HXDW_AUX_WINDOW_ENABLE_MAIN

int main( int argc, const char*const* argv )
{
	//printf("%s - Starting...\n", HxdwAuxMainWindow::getAppTitleText_() );

	printf("Build: %s\n", hxdw_GetDateAtCompileTime("").c_str() );
	printf("\n");

	uint32_t uHKAltTabPassedWhat = 0;
	HxdwAWConfig sAppDTO;
	for( int ii2=1; ii2 < argc; ii2++ ){
		std::string arg0 = argv[ii2];
		std::string arg1 = ( ii2+1 < argc ? argv[ii2+1] : "");
		int nArgAsInt = atoi( arg1.empty() || !isdigit(arg1[0]) ? "1" : arg1.c_str() );
		if( arg0 == "-bStartHidden" ){
			sAppDTO.bStartHidden = !!nArgAsInt;
		}else if( arg0 == "-bTopmost_" ){
			//sAppDTO.x = !!nArgAsInt;
		}
	}
	sAppDTO.srWindowTitle = "Wnd Abc";
	sAppDTO.bWndTitleAddDate = 1L;
	//sAppDTO.bTrayIcon = 1L;
	//sAppDTO.bStartHidden = 1L;
	sAppDTO.bCBMonitor = 1L;
	sAppDTO.calbClipboardChanged2 = []( const HxdwCB2* msg2 )->bool{
		;
		//printf("CB...\n");
		return 1L;
	};
	HxdwAuxMainWindow ti2( sAppDTO );
	ti2.exec2();
	printf("HXDW: Exiting...\n" );
	return 0;
}
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
		LPSTR lpCmdLine, int nCmdShow )
{
	std::vector<std::string> argv2; std::vector<const char*> argv3;
	argv3 = hxdw_GetCommandLine3( &argv2 );
	assert( argv3.size() < 2000000 );
	int rslt = main( (int)argv3.size(), &argv3[0] );
	return rslt;
}
#endif //HXDW_AUX_WINDOW_ENABLE_MAIN

HxdwAuxMainWindow::HxdwAuxMainWindow( const HxdwAWConfig& dto2 )
	: mAppDTO( dto2 )
{
	std::memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
HxdwAuxMainWindow::~HxdwAuxMainWindow()
{
	if( mIsInTray ){
		toggleWindowToTrayVisibility( 1L );
	}
	if( mNid.hWnd ){
		Shell_NotifyIcon( NIM_DELETE, &mNid );
		std::memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	}
	if( mAppDTO.bCBMonitor ){
		//ChangeClipboardChain
		//ChangeClipboardChain(hwnd, hwndNextViewer);
	}
	if( mLoadedFileIcom ){
		DestroyIcon( mLoadedFileIcom );
		mLoadedFileIcom = 0;
	}
}
bool HxdwAuxMainWindow::showMessage2( const char* szMsg, const char* flags2, size_t )
{
	bool bIcnQuestion = !!std::strchr( flags2, 'q');
	bool bIcnError    = !!std::strchr( flags2, 'E');
	bool bIcnInfo     = !!std::strchr( flags2, 'i');
	bool bOkCancel    = !!std::strchr( flags2, 'c');

	int nFlags = 0;
	nFlags |= ( bIcnQuestion ? MB_ICONQUESTION : 0 );
	nFlags |= ( bIcnError    ? MB_ICONERROR    : 0 );
	nFlags |= ( bIcnInfo     ? MB_ICONINFORMATION : 0 );
	nFlags |= ( bOkCancel    ? MB_OKCANCEL     : 0 );
//	nFlags |= MB_APPLMODAL;
	int ans2 = MessageBox( mHwnd, szMsg, getAppTitleText(), nFlags );
	return !!( ans2 == IDOK );
}

const char* HxdwAuxMainWindow::getAppTitleText()
{
	static std::string vAppName;
	if( vAppName.empty() ){
		std::string srDate2;
		{
			const char* date2 = __DATE__, *sz2;
			if( (sz2 = std::strchr( date2, '\x20')) ){
				if( (sz2 = std::strchr( sz2+1, '\x20')) ){
					assert( sz2 > date2 );
					srDate2.assign( date2, sz2 - date2 );
				}
			}
		}
		std::string srAppName = ( !mAppDTO.srWindowTitle.empty() ?
				mAppDTO.srWindowTitle :
				std::string("Anonymous HxdwAuxMainWindow") );
		if( mAppDTO.calbGetWindowTitle ){
			srAppName = mAppDTO.calbGetWindowTitle( mAppDTO.user2 );
		}
		vAppName = hxdw_StrPrintf("%s%s", {
				srAppName.c_str(),
				( mAppDTO.bWndTitleAddDate ? hxdw_StrPrintf(" (%s)",{srDate2,}).c_str() : ""),
				});
	}
	return vAppName.c_str();
}


void HxdwAuxMainWindow::toggleWindowToTrayVisibility( int bShow2 )
{
	assert( mHwnd );
	if( bShow2 == -1 ){
		bShow2 = !IsWindowVisible(mHwnd);
	}
	assert( bShow2 >= 0 && bShow2 <= 1 );
	if( !bShow2 ){
		ShowWindow(mHwnd, SW_HIDE);//SW_MINIMIZE
		mIsInTray = 1L;
	}else{
		ShowWindow(mHwnd, SW_SHOW);
		//ShowWindow(mHwnd, SW_RESTORE);
		SetForegroundWindow(mHwnd);
		mIsInTray = 0L;
	}
}
LRESULT CALLBACK
WndProc2( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	HxdwAuxMainWindow* this2 = (HxdwAuxMainWindow*)GetWindowLongPtr( hWnd, GWLP_USERDATA );
	if(this2){
		return this2->WndProc3( hWnd, msg2, wParam, lParam );
	}
	return DefWindowProc( hWnd, msg2, wParam, lParam );
}
LRESULT HxdwAuxMainWindow::WndProc3( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	if( msg2 == mWMTrayAnyMessageId ){
		if( hxdw_Any<int>( lParam, {WM_LBUTTONDOWN,WM_LBUTTONDBLCLK,} ) ){
			printf("HXDW: tray icon click.\n");
			toggleWindowToTrayVisibility( -1 );
		}
	}else if( msg2 == HxdwAuxMainWindow::mWMDestroyLv2Id ){
		DestroyWindow(hWnd);
	}
	if( mAppDTO.calbOnWndProc2 ){
		HxdwMsg2 sMmsg2 = { hWnd, msg2, wParam, lParam, mAppDTO.user2,};
		HxdwResult2 res2 = mAppDTO.calbOnWndProc2( &sMmsg2 );
		if( res2.first ){
			return res2.second;
		}
	}
	switch(msg2){
	case WM_CREATE:
		assert( mHwnd == hWnd );
		//printf("HXDW: WM_CREATE\n");
		if( mAppDTO.calbOnWndCreate ){
			HxdwWC2 st2 = { mHwnd, mAppDTO.user2,};
			mAppDTO.calbOnWndCreate( &st2 );
		}
		if( mAppDTO.bCBMonitor && !mCbv2.bInited2 ){
			assert( !mCbv2.hwCbvNext );
			assert( mAppDTO.calbClipboardChanged2 );
			mCbv2.hwCbvNext = SetClipboardViewer( mHwnd );
			mCbv2.bInited2 = 1;
			if( !mCbv2.hwCbvNext ){
				std::string sr2 = hxdw_GetLastError();
				if( !sr2.empty() ){
					mCbv2.bInited2 = 0;
					std::string msg4 = hxdw_StrPrintf(
						"Setting up Clipboard Viewer failed [8UixR7]\n[%s]", { sr2,} );
					showMessage2( msg4.c_str(), "E", 0 );
				}
			}
		}
		break;
	case WM_CLOSE:{
			DestroyWindow(hWnd);
		}break;
	case WM_TIMER:
		break;
	case WM_COMMAND:{
			const int wmId = LOWORD(wParam);
			switch( wmId ){
			default:
				break;
			}
		}
		break;
	case WM_DESTROY:
		//printf("HXDW: Processing WM_DESTROY\n");
		if( mAppDTO.bCBMonitor && mCbv2.bInited2 ){
			ChangeClipboardChain( mHwnd, mCbv2.hwCbvNext );
			mCbv2.hwCbvNext = 0;
		}
		PostQuitMessage(0);
		return 1L;
	case WM_SYSKEYDOWN:
	case WM_KEYDOWN:{
			int nVirtKey = (int) wParam;    // virtual-key code, eg. VK_TAB
			const bool bKeyQuit2 = (
				( mAppDTO.bKeyQToQuit && (nVirtKey == 'Q') && !mIsMbxActive ) ||
				( mAppDTO.bKeyXToQuit && (nVirtKey == 'X') && !mIsMbxActive ) ||
				( !mAppDTO.bIgnoreAltF4 && nVirtKey == VK_F4 && GetAsyncKeyState(VK_MENU) ));
			if( bKeyQuit2 ){
				//MessageBox( 0,"","",0);
				bool bAcptd = 0L;
				if( mAppDTO.bConfirmQuit ){
					mIsMbxActive = 1L;
					bAcptd = showMessage2("Quit?", "cq", 0 );
					mIsMbxActive = 0L;
				}else{
					bAcptd = 1L;
				}
				if( bAcptd ){
					//DestroyWindow(hWnd);
					DestroyWindow( mHwnd );
				}
			}
			const bool bPutToTray = ( mAppDTO.bTrayIcon && (
				( mAppDTO.bKeyEscToTray && nVirtKey == VK_ESCAPE ) ||
				( mAppDTO.bKeySpaceToTray && nVirtKey == VK_SPACE && msg2 == WM_KEYDOWN )));
			if( bPutToTray ){
				printf("HXDW: Hide window request...\n");
				toggleWindowToTrayVisibility( 0L );
			}
		}
		break;
	case WM_KEYUP:
	case WM_SYSKEYUP:
		break;
	case WM_HOTKEY:
		break;
	case WM_PAINT:{
		/*	PAINTSTRUCT pst2;
			HDC hdc3 = BeginPaint( hWnd, &pst2 );
			RECT rc2;
			GetClientRect( mHwnd, &rc2 );
			//FillRect( hdc3, &rc2, (HBRUSH)(COLOR_WINDOW+1) );
			FillRect( hdc3, &rc2, mHBrWindow );
			EndPaint( hWnd, &pst2 );//*/
			//return 0;
			//return DefWindowProc( hWnd, msg2, wParam, lParam );
		}break;
	case WM_CHANGECBCHAIN:{
			assert( mAppDTO.bCBMonitor );
			const HWND hwndRemove = (HWND) wParam;     // handle of window being removed
			const HWND hwndNext = (HWND) lParam;       // handle of next window in chain
			if( hwndRemove == mCbv2.hwCbvNext ){
				mCbv2.hwCbvNext = hwndNext;
			}else if( mCbv2.hwCbvNext ){
				return SendMessage( mCbv2.hwCbvNext, WM_CHANGECBCHAIN, wParam, lParam );
			}
		}break;
	case WM_DRAWCLIPBOARD:{
			assert( mAppDTO.bCBMonitor );
			if( mCbv2.bInited2 ){
				UINT uFmt = CF_TEXT;
				if( !mAppDTO.aCBFormats.empty() ){
					uFmt = GetPriorityClipboardFormat( &mAppDTO.aCBFormats[0], mAppDTO.aCBFormats.size() );
				}else{
					uFmt = GetPriorityClipboardFormat( &uFmt, 1 );
				}
				if( !mAppDTO.bCBNoMsg ){
					printf("HXDW: Clipboard format: %d. Is text: [%d]\n", uFmt, (uFmt == CF_TEXT) );
				}
				if( uFmt && uFmt != UINT(-1) ){
					HxdwCB2 scb2;
					scb2.uCBFormat2 = uFmt;
					scb2.nIndex2    = mCBIndex2++;
					if( uFmt == CF_TEXT && mAppDTO.bCBAutoGetText ){
						if( OpenClipboard( mHwnd ) ){
							HANDLE hData2 = GetClipboardData( CF_TEXT );
							assert( hData2 );
							if( hData2 ){
								const char* szData3 = (const char*)hData2;
								size_t len2 = std::strlen( szData3 );
								scb2.srCBText2.assign( szData3, len2 );
								//len2 = std::min<size_t>( len2, 42 );
								//std::string srCbData;
								//srCbData.assign( szData3, len2 );
								//srCbData = hxdw_StrReplace( srCbData, "\r", "<0D>" );
								//srCbData = hxdw_StrReplace( srCbData, "\n", "<0A>" );
								//printf("HXDW: Clipboard: [%s]\n", srCbData.c_str() );
							}
							CloseClipboard();
						}
					}
					mAppDTO.calbClipboardChanged2( &scb2 );
				}
			}
			if( mCbv2.hwCbvNext ){
				return SendMessage( mCbv2.hwCbvNext, WM_DRAWCLIPBOARD, wParam, lParam );
			}
		}break;
	}
	return DefWindowProc( hWnd, msg2, wParam, lParam );
}
ATOM HxdwAuxMainWindow::registerHlprWndClass( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;
	std::memset( &wcex, 0, sizeof(wcex) );
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc2; //(WNDPROC)
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
//	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
//	wcex.hbrBackground = (HBRUSH) CreateSolidBrush( RGB(255,0,0) );
	if( mAppDTO.uClrWindow.first ){
		wcex.hbrBackground = (HBRUSH) CreateSolidBrush( RGB(
				(( mAppDTO.uClrWindow.second >> 0 ) & 0xFF),
				(( mAppDTO.uClrWindow.second >> 8 ) & 0xFF),
				(( mAppDTO.uClrWindow.second >> 16 ) & 0xFF) ));//*/
	}else{
		wcex.hbrBackground = (HBRUSH)0;
	}
	wcex.lpszMenuName = "HXDW:Helper_Class_xQTWCp";
	wcex.lpszClassName = "HXDW:Helper_Class_xQTWCp";

	if( mAppDTO.nWindowIconId.first ){
		wcex.hIcon = LoadIcon( nullptr, mAppDTO.nWindowIconId.second );
	}else if( mAppDTO.hWindowIcon.first ){
		wcex.hIcon = mAppDTO.hWindowIcon.second;
	}else if( mAppDTO.srWindowIconFile.first ){
		assert( !mLoadedFileIcom );
		mLoadedFileIcom = hxdw_LoadIconFromFile( mAppDTO.srWindowIconFile.second.c_str(), 0 );
		assert( mLoadedFileIcom );
		wcex.hIcon = mLoadedFileIcom;
	}else{
		// IDI_INFORMATION = 32516 = IDI_ASTERISK
		// IDI_WARNING = 32515
		wcex.hIcon = LoadIcon( nullptr, IDI_INFORMATION );
	}
	return RegisterClassEx(&wcex);
}
void HxdwAuxMainWindow::initializeTrayIcon()
{
	std::memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	mNid.cbSize           = sizeof(NOTIFYICONDATA);
	mNid.hWnd             = mHwnd;
	mNid.uID              = 1001;// uId ? ++uId : uId = 1;
	mNid.uFlags           = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	mNid.uCallbackMessage = mWMTrayAnyMessageId;   //WM_USER+NNN
	mNid.hIcon            = hxdw_GetWindowIcon( mHwnd );
	assert( mNid.hIcon );
	//
	std::snprintf( mNid.szTip, sizeof(mNid.szTip), "%s", hxdw_GetWindowText( mHwnd ).c_str() );
	Shell_NotifyIcon( NIM_ADD, &mNid );
}
bool HxdwAuxMainWindow::initInstance( HINSTANCE hInstance, int nCmdShow )
{
	const std::array<int,2> aWHScrn = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
	assert( !mHwnd );
	mHwnd = CreateWindow("HXDW:Helper_Class_xQTWCp", getAppTitleText(), WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0,
		int(aWHScrn[0] * 0.4f),
		int(aWHScrn[1] * 0.4f),
		NULL, NULL, NULL, NULL );
	if( !mHwnd ){
		showMessage2("ERROR: Failed creating the main window!", "E", 0 );
		return 0L;
	}
	SetWindowLongPtr( mHwnd, GWLP_USERDATA, (LONG_PTR)this );
	SendMessage( mHwnd, WM_CREATE, 0, 0 );
	if( mAppDTO.bStartHidden ){
		ShowWindow( mHwnd, SW_HIDE );
	}else{
		ShowWindow( mHwnd, nCmdShow ); //SW_SHOW
	}
	if( mAppDTO.bTrayIcon ){
		initializeTrayIcon();
	}
	return 1L;
}
int HxdwAuxMainWindow::exec2()
{
	registerHlprWndClass( GetModuleHandle(0) );
	bool rs2 = initInstance( GetModuleHandle(0), SW_SHOW );
	if( !rs2 ){
		return 255;
	}
	assert( !mDwMainThreadId );
	mDwMainThreadId = GetCurrentThreadId();

	MSG msg;
	while( GetMessage( &msg, nullptr, 0, 0 ) ){
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	return static_cast<int>( msg.wParam );
}
bool HxdwAuxMainWindow::closeWindow()
{
	assert( mHwnd );
	bool rs2 = !!DestroyWindow( mHwnd );
	return rs2;
}
