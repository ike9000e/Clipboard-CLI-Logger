#include "hxdw_utils.h"
#include <stdint.h>
#include <assert.h>
//#include <memory>
#include <string>
#include <cinttypes> //std::strtoimax()
#include <limits>  //std::numeric_limits
#ifdef _MSC_VER
	#pragma warning( disable : 4091 ) // Win SDK 7.1 | shlobj.h warning C4091: typedef ignored on left of tagGPFIDL_FLAGS ...
#endif
#include <shlobj.h>
#include <commdlg.h>    //OPENFILENAME
#include <winioctl.h>   //FSCTL_GET_REPARSE_POINT
#include <shellapi.h>   //CommandLineToArgvW()
//#include <psapi.h>      //CreateToolhelp32Snapshot()
//#include <tlhelp32.h>   //CreateToolhelp32Snapshot()

#ifdef _MSC_VER
	//#define _CRT_SECURE_NO_WARNINGS 1
	#pragma warning (disable: 4996)  //fopen() unsafe.
	#pragma warning (disable: 4706)  //assignment within conditional expression.
	#pragma warning (disable: 4100)  //unreferenced formal parameter.
	// /wd<n> disable warning n
	// /wd4996
#endif //_MSC_VER

// vector(960): warning C4530: C++ exception handler used, but unwind
// semantics are not enabled. Specify /EHsc (aka. /GX)

uint32_t HxPrintfBase::LGlobalLevel = 4;

/// Used internally by hxdw_FindWindowByCaptionPart().
struct hxdw_WndEnumFuncCalbData{
	std::function<bool(HWND, const char*)> calb5;
};
BOOL CALLBACK hxdw_WndEnumFunc( HWND hwnd, LPARAM lParam )
{
	//char classname2[256];
	//GetClassName( hwnd, classname2, 256 );
	char caption2[256];
	GetWindowText( hwnd, caption2, 256 );
	hxdw_WndEnumFuncCalbData* cd2 = (hxdw_WndEnumFuncCalbData*)lParam;
	//if( !(*cd2->calb4_)( hwnd, caption2 ) )
	if( !(cd2->calb5)( hwnd, caption2 ) ){
		return 0;
	}
	return 1;
}
/// Finds window by partial text of caption (title).
/// old: hxdw_FindWndByCaptionPart().
HWND hxdw_FindWindowByCaptionPart( const char* szNeedle, const char* flags2 )
{
	std::vector<HWND> wnds;
	auto calb2 = [&]( HWND hwnd2, const char* szCaption )->bool{
		bool bFound = !!strstr( szCaption, szNeedle );
		if(bFound)
			wnds.push_back(hwnd2);
		return 1;
	};
	hxdw_WndEnumFuncCalbData cdt;
	cdt.calb5   = calb2;
	EnumWindows( hxdw_WndEnumFunc, (LPARAM)&cdt );
	if( strchr( flags2, 'b' ) ){
		return ( wnds.empty() ? 0 : wnds.back() );
	}else{
		return ( wnds.empty() ? 0 : wnds[0] );
	}
}

bool hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames, const char* flags2 )
{
	const bool bWide = !!strchr( flags2, 'w' );
	int len2 = sizeof(DROPFILES);
	for( auto sr2 : fnames ){
		len2 += strlen(sr2.c_str()) + 1;
	}
	len2 += 1; //one more for extra null terminator.
	HGLOBAL hGlobal = GlobalAlloc( GHND, len2 );
	if( !hGlobal ){
		printf("CPTA DLL: ERROR: global data alloc failed.\n");
		return 0;
	}
	DROPFILES* dfi = static_cast<DROPFILES*>(GlobalLock(hGlobal));
	dfi->pFiles = sizeof(DROPFILES);
	dfi->fWide = ( bWide ? 1 : 0 );
	//dfi->fNC = 1;
	//dfi->pt.x = dfi->pt.y = 100;
	int len3 = len2 - sizeof(DROPFILES);
	assert( len3 > 0 );
	char* pStrDataBgn = reinterpret_cast<char*>(dfi) + sizeof(DROPFILES);
	char* pStrDataEnd = pStrDataBgn + len3;
	int nWri = 0;
	char* ptr;
	for( const auto& sr2 : fnames ){
		ptr = &pStrDataBgn[nWri];
		assert( ptr < pStrDataEnd );
		memcpy( ptr, sr2.c_str(), sr2.size() + 1 );
		nWri += sr2.size() + 1;
	}
	ptr = &pStrDataBgn[nWri];
	assert( ptr < pStrDataEnd );
	*ptr = 0;  // write extra null terminator.
	printf("CPTA DLL Sending message...\n");
	bool rs2 = !!PostMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	//bool rs2 = !!SendMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	if( !rs2 ){
		printf("CPTA DLL: ERROR: post message failed.\n");
		GlobalFree(hGlobal);
		return 0;
	}
	return 1;
}
/*
template<class T>
bool hxdw_SendDropFilesToWnd2( HWND hwnd, const std::vector<std::basic_string<T>>& fnames, const char* flags2 )
{
	const bool bWide = ( sizeof(T) >= 2 ? 1 : 0 ); //!!strchr( flags2, 'w' );
	int len2 = sizeof(DROPFILES);
	for( auto sr2 : fnames ){
		len2 += sr2.size() * sizeof(T) + sizeof(T);
	}
	len2 += sizeof(T); //one more for extra null terminator.
	HGLOBAL hGlobal = GlobalAlloc( GHND, len2 );
	if( !hGlobal ){
		printf("CPTA DLL: ERROR: global data alloc failed.\n");
		return 0;
	}
	DROPFILES* dfi = static_cast<DROPFILES*>(GlobalLock(hGlobal));
	dfi->pFiles = sizeof(DROPFILES);
	dfi->fWide = ( bWide ? 1 : 0 );
	int len3 = len2 - sizeof(DROPFILES);
	assert( len3 > 0 );
	T* pStrDataBgn = reinterpret_cast<T*>(dfi) + sizeof(DROPFILES);
	T* pStrDataEnd = pStrDataBgn + len3;
	int nWri = 0;
	T* ptr;
	for( const auto& sr2 : fnames ){
		ptr = &pStrDataBgn[nWri];
		assert( ptr < pStrDataEnd );
		int num = (sr2.size() * sizeof(T)) + sizeof(T);
		memcpy( ptr, sr2.c_str(), num );
		nWri += num;
	}
	ptr = &pStrDataBgn[nWri];
	assert( ptr < pStrDataEnd );
	*ptr = 0;  // write extra null terminator.
	printf("CPTA DLL Sending WM_DROPFILES message...\n");
	bool rs2 = !!PostMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	//bool rs2 = !!SendMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	if( !rs2 ){
		GlobalFree(hGlobal);
		return 0;
	}
	return 1;
}
template bool hxdw_SendDropFilesToWnd2( HWND hwnd, const std::vector<std::basic_string<char>>& fnames, const char* flags2 );
template bool hxdw_SendDropFilesToWnd2( HWND hwnd, const std::vector<std::basic_string<WCHAR>>& fnames, const char* flags2 );
//*/

std::string hxdw_StrImplode( const std::vector<std::string>& parts2, const std::string glue2, const char* szTrimLR )
{
	std::string z; int i = 0;
	for( auto str : parts2 ){
		if( i )
			z += glue2;
		if(szTrimLR)
			str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
		z += str;
		i++;
	}
	return z;
}
void hxdw_StrExplode2( const char* inp,
					std::function<void(const char*, int len)> calbNewPart,
					const std::vector<std::string> lsGlueItems2,
					int nLimitSplitPoints, const char* szTrimLR )
{
	assert( !lsGlueItems2.empty() );
	const char* sz2 = inp;
	for( ; nLimitSplitPoints; --nLimitSplitPoints ){
		const char *sz3 = 0;
		int nLenGlue = -1;
		{
			const char* sz4;
			for( auto glue2 : lsGlueItems2 ){
				if( (sz4 = std::strstr( sz2, glue2.c_str() ) ) ){
					if( nLenGlue == -1 || sz4 < sz3 ){
						sz3 = sz4;
						nLenGlue = (int) glue2.size();
					}
				}
			}
		}
		if(!sz3)
			break;
		assert( nLenGlue != -1 );
		assert( sz2 <= sz3 );
		if( sz2 <= sz3 ){
			std::string str( sz2, sz3-sz2 );
			if( szTrimLR )
				str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
			calbNewPart( str.c_str(), (int) str.size() );
		}
		sz2 = sz3 + nLenGlue;
	}
	if( sz2 ){
		std::string str( sz2 );
		if( szTrimLR )
			str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
		calbNewPart( str.c_str(), (int) str.size() );
	}
}
/**
	String explode into parts.
	\param nLimitSplitPoints - limit numer of splits, -1: no limit. eg. if set to 2, yelds 3 output parts.
	\param flags3 - optional, flags as c-string.
					'e': remove empty.
					't': remove tail empty.
*/
bool hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2,
					const std::vector<std::string> lsGlueItems,
					int nLimitSplitPoints, const char* szTrimLR,
					const char* flags3 )
{
	assert( !lsGlueItems.empty() );
	//const size_t uNumOrig = parts2.size();
	hxdw_StrExplode2( inp, [&]( const char* sz2, int len ){
		parts2.push_back( std::string( sz2, len ) );
	}, lsGlueItems, nLimitSplitPoints, szTrimLR );
	{	// process flags.
		const bool bRemoveEmpty = !!std::strchr( flags3, 'e');
		if( bRemoveEmpty ){
			auto ir2 = parts2.begin();
			//std::advance( ir2, uNumOrig );
			for( ; ir2 != parts2.end(); ){
				if( ir2->empty() ){
					ir2 = parts2.erase( ir2 );
				}else{
					++ir2;
				}
			}
		}
		const bool bRmvTailEmpty = !!std::strchr( flags3, 't');
		if( bRmvTailEmpty ){
			int ii2 = (((int)parts2.size()) - 1 );
			for( ; ii2 > -1 && parts2[ii2].empty(); ii2-- ){
				auto ir3 = parts2.begin();
				std::advance( ir3, ii2 );
				parts2.erase( ir3 );
			}
		}
	}
	return 1;
}
/// Returns pair of base file name part and extension.
/// Extension is without the leading dot character.
/// If the input came with the path part, then path part is
/// included in the output within the base file name part, the first component.
/// If the file name is extension-less, then the second component is returned empty.
std::pair<std::string,std::string> hxdw_SplitExt( std::string filename2 )
{
	const char* inp = filename2.c_str();
	//int pos = -1;
	const char* sz2 = strrchr( inp, '\\');
	const char* sz3 = strrchr( inp, '/');
	const char* sz4 = strrchr( inp, '.');
	sz2 = ( sz2 && sz3 ? std::min<const char*>(sz2,sz3) : ( sz2 ? sz2 : sz3 ) );
	if( sz4 && sz4 > sz2 && sz4[1] != 0 ){
		std::string a( inp, sz4-inp );
		std::string b( sz4 + 1 );
		return {a,b,};
	}
	return {inp,"",};
}
/// Tests if file or directory exists.
/// \sa hxdw_IsDir()
/// \sa hxdw_MkdirRcv()
bool hxdw_FileExists( const char* fname )
{
	WIN32_FIND_DATA FindFileData;
	HANDLE handle2 = FindFirstFile( fname, &FindFileData) ;
	bool bFound = handle2 != INVALID_HANDLE_VALUE;
	if( bFound ){
		FindClose( handle2 );
	}
	return bFound;
}

/**
	Tests if path is an existing directory.
	\sa hxdw_FileExists()
*/
bool hxdw_IsDir( const char* pathname )
{
	if( hxdw_FileExists(pathname) ){
		bool bDir = !!( FILE_ATTRIBUTE_DIRECTORY & GetFileAttributes( pathname ) );
		return bDir;
	}
	return 0;
}
std::string hxdw_GetTextFileContents( const char* fname )
{
	std::string outp;
	char buf[2048];
	FILE* fp2 = nullptr;
	size_t nread;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( fp2 ){
			std::fclose(fp2);
			fp2 = nullptr;
		}
	});

	//The fopen_s instead warning. To disable deprecation, use _CRT_SECURE_NO_WARNINGS.
	fp2 = std::fopen( fname, "rb" );
	if( !fp2 ){
		return "";
	}
	std::fseek( fp2, 0, SEEK_SET );
	while( (nread = std::fread(buf, 1, sizeof(buf), fp2)) > 0 ){
		outp.append( buf, nread );
		//std::fseek( hf2, nread, SEEK_CUR );
	}
	if( std::ferror(fp2) ){
		return "";
	}
	return outp;
}
bool
hxdw_ReadBinaryFileContents( const char* fname,
		HxdwSizeAdp nMaxRead2,
		std::function<bool( const uint8_t*, uint32_t len )> calb2,
		uint32_t uStartPos, uint32_t nRqBufSize )
{
	assert( nRqBufSize );
	std::vector<char> buf;
	buf.resize( nRqBufSize );  //2048
	assert( buf.size() == nRqBufSize );

	FILE* fp2 = nullptr;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( fp2 ){
			fclose(fp2);
			fp2 = nullptr;
		}
	});
	uint32_t nMaxRead = (uint32_t) nMaxRead2.uSize;
	if( nMaxRead2.bUnlimited ){
		//if( sizeof(nMaxRead) == 4 ){
			nMaxRead = 0xFFFFFFFF;
		//}else{
		//	//std::numeric_limits<size_t>::max();  //fails to compile on MSVC.
		//	nMaxRead = (size_t)0xFFFFFFFFFFFFFFFF;
		//}
	}else{
		assert( nMaxRead );
	}
	fp2 = fopen( fname, "rb" );
	if( !fp2 ){
		return 0L;
	}
	//fseek( fp2, 0, SEEK_SET );
	fseek( fp2, uStartPos, SEEK_SET );
	uint32_t nTotalReadd = 0u, nreadd = 0u;

	for( ; nMaxRead > nTotalReadd; nTotalReadd += nreadd ){
		const uint32_t nToRead = std::min<uint32_t>( nMaxRead-nTotalReadd, buf.size() );
		if( (nreadd = fread( &buf[0], 1, nToRead, fp2)) <= 0 ){
			break;
		}
	//	// append.
	//	const size_t uOldsize = outp.size();
	//	outp.resize( uOldsize + nreadd );
	//	memcpy( &outp[uOldsize], &buf[0], nreadd );
	//	//std::fseek( hf2, nreadd, SEEK_CUR );

		if( !calb2( (uint8_t*) &buf[0], nreadd ) ){
			break;
		}
	}
	if( ferror(fp2) ){
		return 0L;
	}
	return 1L;
}
std::vector<uint8_t>
hxdw_GetBinaryFileContents( const char* fname, size_t nMaxRead )
{
	std::vector<uint8_t> outp;
	bool rs2;
	rs2 = hxdw_ReadBinaryFileContents( fname,
			HxdwSizeAdp( (uint64_t) nMaxRead),
			[&]( const uint8_t* data2, size_t nreadd )->bool{
				assert( nreadd );
				// append.
				const size_t uOldsize = outp.size();
				outp.resize( uOldsize + nreadd );
				memcpy( &outp[uOldsize], data2, nreadd );
				return 1L;
	}, 0, 65536 );
	if(rs2){
	}
	return outp;
}
bool hxdw_GetTextLinesFromFile( const char* fname,
								std::vector<std::string>* lines2 )
{
	std::vector<std::string> lines3;
	std::string data2 = hxdw_GetTextFileContents( fname );
	hxdw_StrExplode( data2.c_str(), lines3, {"\n",}, -1, "\r\n" );
	for( auto& a : lines3 ){
		if( !a.empty() ){
			lines2->push_back( a );
		}
	}
	return 1;
}
/// Retrieves command line single argument given 1 or more of its names.
/// names2  - arg-names.
/// szFlags - flags as c-string characters.
///           b: boolean, returns "1" if name has been found.
///           i: case insensitive.
std::string
hxdw_GetArgvByName( const std::vector<std::string> names2,
						int argc2, const char*const* argv2, const char* szFlags )
{
	bool bBool = strchr( szFlags, 'b' );
	bool bCasei = strchr( szFlags, 'i' );
	for( int i=0; i<argc2; i++ ){
		std::string val2, name3 = argv2[i];
		auto a = std::find_if( names2.begin(), names2.end(), [&]( const std::string& a )->bool{
			if( bCasei ){
				return !lstrcmpi( a.c_str(), name3.c_str() );
			}else{
				return a == name3;
			}
		});
		if( a != names2.end() ){
			i++;
			val2 = ( bBool ? "1" : ( i < argc2 ? argv2[i] : "" ) );
			return val2;
		}
	}
	return "";
}

bool hxdw_IsWithPathPart( std::string pathname )
{
	const char* sz2 = std::strrchr( pathname.c_str(), '/' );
	const char* sz3 = std::strrchr( pathname.c_str(), '\\' );
	return sz2 || sz3;
}
/**
	Tests if path is absolute.
	Returns true if it starts with letters followed by colon.
	Example of absolute paths:
		"c:/windows", "c:\\windows",
		"c:/", "c:",
		"steam://rungameid/123456".
*/
bool hxdw_IsAbsolutePath( const std::string& pathname )
{
	if( pathname.size() >= 2 ){
		size_t ii2;
		// scan until non-alphanum.
		for( ii2 = 0; ii2 < pathname.size(); ii2++ ){
			if( !hxdw_TestCharClass( pathname[ii2], "da") )
				break;
		}
		if( pathname[ii2] == ':' ){
			return 1;
		}
	}
	;
	return 0;
}
/// Tests whenever path is relative, in respect to current directory.
/// Returns true for paths like "dir2/a.bin",
/// or - file name only paths - like "b.txt".
bool hxdw_IsPathCDRelative( const std::string& pathname )
{
	if( pathname.empty() )
		return 0;
	if( hxdw_IsAbsolutePath( pathname ) )
		return 0;
	const char ch0 = pathname[0];
	if( std::strchr( "\\/", ch0 ) ){
		return 1;
	}
	if( hxdw_TestCharClass( ch0, "a") ){
		// that it is not a path with 2nd char being colon,
		// is excluded at the absolute path step test above.
		return 1;
	}
	return 0;
}
/// Given input path name splits it into dirname and basename pair.
/// Eg. "c:/temp/a.txt" ---> "c:/temp" and "a.txt".
/// Eg. "./data/x.txt"  ---> "./data"  and "x.txt".
/// Eg. "b.txt"         ---> ""        and "b.txt".
std::pair<std::string,std::string> hxdw_SplitPath( std::string inp2 )
{
	inp2 = hxdw_TrimStr( inp2, "\\/", "R", -1 );
	{
		const char* inp = inp2.c_str();
		const char* sz2 = std::strrchr( inp, '/' );
		const char* sz3 = std::strrchr( inp, '\\' );
		if( (sz2 = std::max<const char*>( sz2, sz3 )) ){
			std::string dirname2( inp, sz2-inp );
			return { dirname2, &sz2[1] };
		}
		return {"", inp,};
	}
}
std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 )
{
	std::string outp;
	int nCount = 0, nRCount = 0;
	bool bLeft = 1, bRight = 1;
	if( flags2 && *flags2 ){
		bLeft = !!strchr( flags2, 'L' );
		bRight = !!strchr( flags2, 'R' );
	}
	if( bLeft ){
		std::string::const_iterator a;
		for( a = inp.begin(); a != inp.end() && limit2 != nCount; ++a, nCount++ ){
			if( charset2.find( *a ) == std::string::npos )
				break;
		}
	}
	if( bRight ){
		std::string::const_reverse_iterator b;
		for( b = inp.rbegin(); b != inp.rend() && limit2 != nRCount; ++b, nRCount++ ){
			if( charset2.find( *b ) == std::string::npos )
				break;
		}
	}
	size_t nChop = static_cast<size_t>( nCount + nRCount );
	//assert( nChop <= inp.size() );
	//if( nChop == inp.size() ){}
	if( nChop >= inp.size() ){
		return "";
	}
	outp = inp.substr( nCount, inp.size() - nChop );
	return outp;
}
hxdw_IniData2
hxdw_ParseINIData( const char* data2, int size_ )
{
	hxdw_IniData2 ini2;
	std::vector<std::string> lines2;
	std::vector<std::string>::const_iterator a;
	std::string intrm2;
	assert( size_ >= -1 );
	if( size_ == -1 ){
		// intrm2 unused.
	}else{
		intrm2.assign( data2, size_ );
		data2 = intrm2.c_str();
	}
	hxdw_StrExplode( data2, lines2, {"\n",}, -1, "\r\n\t\x20", "" );
	for( a = lines2.begin(); a != lines2.end(); ++a ){
		if( !a->empty() ){
			if( (*a)[0] == '[' && ((*a).back() == ']') ){ //0x5B: bracket open.
				hxdw_IniSection el2;
				el2.first = a->substr( 1, a->size() - 2 );
				ini2.sections2.push_back( el2 );
			}else if( strchr("#;", (*a)[0] ) ){ //if comment
				// just ignore commented out line.
			}else{
				if( ini2.sections2.empty() )
					ini2.sections2.push_back( hxdw_IniSection() );
				std::vector<std::string> kval;
				hxdw_StrExplode( a->c_str(), kval, {"=",}, 1, "\r\n\t\x20" );
				if( kval.size() < 2 )
					kval.insert( kval.begin(), ""); //so that the key is empty.
				kval.resize(2);
				if( kval[1].size() >= 2 ){ // then check for quotes strip.
					if( strchr("\x22\x27", kval[1][0] ) && kval[1][0] == kval[1].back() )
						kval[1] = kval[1].substr( 1, kval[1].size() - 2 );
				}
				ini2.sections2.back().second.push_back( { kval[0], kval[1],} );
			}
		}
	}
	return ini2;
}
hxdw_IniData2 hxdw_ParseINIFile( const char* szIniFname )
{
	hxdw_IniData2 ini2;
	std::string data3;
	data3 = hxdw_GetTextFileContents( szIniFname );
	ini2 = hxdw_ParseINIData( data3.c_str(), -1 );
	return ini2;
}
bool hxdw_IniData2::
eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const
{
	hxdw_IniData3::const_iterator a;
	for( a = sections2.begin(); a != sections2.end(); ++a ){
		if( !calb2( *a ) )
			break;
	}
	return 1;
}
/// Enumerates INI variables.
/// \param sectnames - if eempty, variables in all sections are enumerated.
bool hxdw_IniData2::
eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* val2 )> calb3 )const
{
	bool rs2 = eachSection( [&]( const hxdw_IniSection& sec2 ){
		if( !sectnames.empty() ){
			auto b = std::find( sectnames.begin(), sectnames.end(), sec2.first );
			if( b == sectnames.end() )
				return 1;
		}
		for( const auto& aVar : sec2.second ){
			if( !calb3( sec2.first.c_str(), aVar.first.c_str(), aVar.second.c_str() ) ){
				return 0;
			}
		}
		return 1;
	});
	return rs2;
}
std::string hxdw_IniData2::getValue( const char* sec2, const char* kname2, const char* default2 )const
{
	std::string val2; bool bFound = 0;
	eachVariable( {sec2,}, [&]( const char* secname, const char* kname3, const char* value2 ){
			if(secname){}
			if( !strcmp( kname2, kname3 ) ){
				val2 = value2;
				bFound = 1;
				return 0;
			}
			return 1;
	});
	if( !bFound && default2 )
		return default2;
	return val2;
}
bool hxdw_IniData2::setValue( const char* sec2, const char* kname2, const char* value3 )
{
	for( auto& a : sections2 ){
		if( a.first == sec2 ){
			for( auto& b : a.second ){
				if( b.first == kname2 ){
					b.second = value3;
					return 1;
				}
			}
			// variable hasnt benn found. insert it as new to current section.
			a.second.push_back( { kname2, value3,} );
			return 1;
		}
	}
	// section hasnt benn found. insert new section now, and its only variable.
	sections2.push_back( hxdw_IniSection() );
	sections2.back().first = sec2;
	sections2.back().second.push_back( { kname2, value3,} );
	return 1;
}
/**
	Tests wherever input character is of specified character class.

	\param flags2 - Character class specified as c-string flags.
					Flags:
						d: decimal 0-9.
						a: alpabet, a-z or A-Z.
						h: hex digits a-f or A-F.
						w: whitespace. ("\x20\t\r\n\x0B", 0x0B=VT)
						l: lowercase.
						u: uppercase.
					if neither 'l' or 'u' is specified, test is
					done for both cases, lowercase and uppercase.
					Eg. "a" - tests for a-z or A-Z.
					.   "al" - tests for a-z. ie. lowercase only.
					.   "d" - tests for 0-9.
*/
bool hxdw_TestCharClass( int inp, const char* flags2 )
{
	const bool bDec   = !!std::strchr( flags2, 'd');
	const bool bAlpha = !!std::strchr( flags2, 'a');
	const bool bHex   = !!std::strchr( flags2, 'h');
	bool       bLcase = !!std::strchr( flags2, 'l');
	bool       bUcase = !!std::strchr( flags2, 'u');
	bool       bWhitespace = !!std::strchr( flags2, 'w');
	if( bDec ){
		if( (inp >= '1' && inp <= '9') || (inp == '0') )
			return 1;
	}
	if( bWhitespace ){
		// 0x0B: VT (vertical tab)
		if( !!std::strchr( "\x20\r\n\t\x0B", inp ) )
			return 1;
	}
	if( ( bAlpha || bHex ) && ( !bLcase && !bUcase ) ){
		bLcase = bUcase = 1;
	}
	if( bAlpha ){
		if( bLcase && (inp >= 'a' && inp <= 'z') )
			return 1;
		if( bUcase && (inp >= 'A' && inp <= 'Z') )
			return 1;
	}
	if( bHex ){
		if( bLcase && (inp >= 'a' && inp <= 'f') )
			return 1;
		if( bUcase && (inp >= 'A' && inp <= 'F') )
			return 1;
	}
	return 0;
}

int hxdw_StrCmpOpt( const char* a, const char* b, int num, const char* flags2 )
{
	const bool bCi = !!std::strchr( flags2, 'i');
	for( ; *a && *b && num; ++a, ++b, --num ){
		if( *a != *b ){
			if(bCi){
				char ch2 = *a, ch3 = *b;
				//hxdw_TestCharClass
				ch2 = ( ch2 >= 'a' && ch2 <= 'z' ? (ch2 - ('a'-'A')) : ch2 );
				ch3 = ( ch3 >= 'a' && ch3 <= 'z' ? (ch3 - ('a'-'A')) : ch3 );
				if( ch2 != ch3 ){
					break;
				}
			}else{
				break;
			}
		}
	}
	return ( !num ? 0 : ( static_cast<int>( *a ) - static_cast<int>( *b ) ) );
}
int hxdw_GetFileSize( const char* fname )
{
	FILE* fp2 = fopen( fname, "r" );
	if( fp2 ){
		fseek( fp2, 0, SEEK_END );
		int nEnd = (int)ftell( fp2 );
		fclose(fp2);
		return nEnd;
	}
	return 0;
}
uint64_t hxdw_GetFileSize2( const char* fname )
{
	//DWORD dwLo = GetFileSize( 00, &dwHi );
	WIN32_FILE_ATTRIBUTE_DATA fileInfo;
	static_assert( sizeof(uint64_t) == 8, "" );
	static_assert( sizeof(DWORD) == 4, "" );
	static_assert( sizeof(fileInfo.nFileSizeHigh) == 4, "" );
	static_assert( sizeof(fileInfo.nFileSizeLow) == 4, "" );
	memset( &fileInfo, 0, sizeof(fileInfo) );
	if( !GetFileAttributesEx( fname, GetFileExInfoStandard, (void*)&fileInfo ) )
		return 0;
	uint64_t outp = 0;
	outp |= ( 0xFFFFFFFF & fileInfo.nFileSizeLow );
	outp |= ( uint64_t(fileInfo.nFileSizeHigh) << 32 );
	return outp;
}
// fseek, _fseeki64
// int _fseeki64( FILE *stream, __int64 offset, int origin );
// https://docs.microsoft.com/en-us/cpp/c-runtime-library/reference/fseek-fseeki64?view=vs-2019
bool hxdw_Fseek64( FILE* fp2, uint64_t offset2 )
{
	return !_fseeki64( fp2, offset2, SEEK_SET );
}

std::vector<std::string>
hxdw_IniData2::getSectionsByNamePrefix( const char* szPrefix, const char* flags2 )const
{
	if(flags2){}
	std::vector<std::string> outp;
	int len = (int)strlen( szPrefix );
	if(!len)
		return outp;
	eachSection( [&]( const hxdw_IniSection& sec2 ){
		if( !hxdw_StrCmpOpt( sec2.first.c_str(), szPrefix, len, "" ) ){
			outp.push_back( sec2.first );
		}
		return 1;
	});
	return outp;
}

std::string hxdw_IniData2::getAsString()const
{
	auto clearBadChars2 = []( std::string& inp, char chr = '_' )->void{
		std::replace( inp.begin(), inp.end(), '\r', chr );
		std::replace( inp.begin(), inp.end(), '\n', chr );
		std::replace( inp.begin(), inp.end(), '=', chr );
		std::replace( inp.begin(), inp.end(), '\x22', chr );
		std::replace( inp.begin(), inp.end(), '\x27', chr );
		std::replace( inp.begin(), inp.end(), '\x20', chr );
	};
	auto clearBadChars3 = []( std::string& inp, char chr = '\x20' )->void{
		std::replace( inp.begin(), inp.end(), '\r', chr);
		std::replace( inp.begin(), inp.end(), '\n', chr);
		std::replace( inp.begin(), inp.end(), '\x22', chr);
		std::replace( inp.begin(), inp.end(), '\x27', chr);
	};

	std::string outp, key2, val2;
	eachSection( [&]( const hxdw_IniSection& sec2 ){
			std::vector<std::pair<std::string,std::string> >::const_iterator a;
			if( !outp.empty() )
				outp += "\r\n";
			outp += "[" + sec2.first + "]\r\n";
			size_t nLenMin = 0;
			for( a = sec2.second.begin(); a != sec2.second.end(); ++a ){
				nLenMin = std::max<size_t>( nLenMin, a->first.size() );
			}
			for( a = sec2.second.begin(); a != sec2.second.end(); ++a ){
				bool bHasSpc = 0;
				key2 = a->first;
				val2 = a->second;
				clearBadChars2( key2 );
				clearBadChars3( val2 );
				bHasSpc = ( std::find( val2.begin(), val2.end(), '\x20' ) != val2.end() );
				if( key2.size() < nLenMin )
					key2.resize( nLenMin, '\x20' );  //padd with spaces so it aligns.
				outp += key2 + " = ";
				if( bHasSpc ){
					outp += "\x22" + val2 + "\x22\r\n";
				}else{
					outp += val2 + "\r\n";
				}
			}
			return 1;
	});
	return outp;
}
/// Updates INI file properties.
/// Other properties are left unchanged.
bool hxdw_IniData2::
updateINIValues( std::function<bool(std::string* sectionn, std::string* varnamee, std::string* valuee)> calb2 )
{
	for( ;; ){   //for each INI property - via the input callback.
		std::string bfrSec, bfrVrn, bfrVal;
		const bool rs2 = calb2( &bfrSec, &bfrVrn, &bfrVal );
		if( !rs2 && bfrSec.empty() && bfrVrn.empty() && bfrVal.empty() ){
			break;
		}
		bool bUpdated = 0;
		auto irS = std::find_if(
				sections2.begin(), sections2.end(), [&]( const hxdw_IniSection& inp )->bool{
					return inp.first == bfrSec;
				} );
		if( irS != sections2.end() ){
			const auto endd = irS->second.end();
			for( auto irVn = irS->second.begin(); irVn != endd; ++irVn ){
				if( irVn->first == bfrVrn ){
					//printf("replacing value.\n");
					irVn->second = bfrVal;
					bUpdated = 1;
					break;
				}
			}
			if( !bUpdated ){
				irS->second.push_back( { bfrVrn, bfrVal,} );
				bUpdated = 1;
			}
		}
		if( !bUpdated ){
			sections2.push_back( { bfrSec, { { bfrVrn, bfrVal,},},} );
			bUpdated = 1;
		}
		if( !rs2 ){
			break;
		}
	}
	return 1;
}
/// Updates INI file properties on the disk file.
/// Reads INI from the disk first. Other properties are left unchanged.
bool hxdw_IniData2::updateINIFileValues(
			const char* szINIFname,
			std::function<bool(std::string* sectionn, std::string* varnamee, std::string* valuee)> calb2
			) //static
{
	hxdw_IniData2 ini3 = hxdw_ParseINIFile( szINIFname );
	ini3.updateINIValues( calb2 );
	std::string data2 = ini3.getAsString();
	bool rs3 = hxdw_PutFileContents( szINIFname, data2.c_str(), data2.size(), "" );
	return rs3;
}
/// Updates properties in this INI from properties found in the other INI.
/// Regarding this INI, if same property already exists,
/// it is replaced.
bool hxdw_IniData2::updateFrom( const hxdw_IniData2& otherr )
{
	hxdw_IniData2* this2 = this;
	otherr.eachVariable( {},
		[&]( const char* secname, const char* kname, const char* value2 )->bool{
			this2->setValue( secname, kname, value2 );
			return 1;
	} );
	//updateINIValues( [&](
	//		std::string* sectionn, std::string* varnamee, std::string* valuee
	//	)->bool{
	//		return 1;
	//} );
	return 1;
}
bool hxdw_IniData2::isINIEmpty()const
{
	return sections2.empty();
}

/// Rerurns time ticks in microseconds.
/// 1'000'000 = 1 second.
uint64_t hxdw_GetTimeTicksUs()
{
	return hxdw_GetPosixTimeUs();
}
/// Returns POSIX time in microseconds.
/// Format is: POSIX time in microseconds, 1'000'000 = 1 second.
/// ref: https://stackoverflow.com/questions/4568221/c-get-system-time-to-microsecond-accuracy-on-windows
/// -    https://docs.microsoft.com/en-us/windows/desktop/sysinfo/acquiring-high-resolution-time-stamps
uint64_t hxdw_GetPosixTimeUs()
{
	FILETIME ftm;
	GetSystemTimeAsFileTime( &ftm );
	uint64_t ttm = ftm.dwHighDateTime; //unsigned long long
	ttm <<= 32;
	ttm |= ftm.dwLowDateTime;
	ttm /= 10;
	ttm -= 11644473600000000ULL;
	return  ttm;
}
uint64_t hxdw_GetTimeTicksMs()
{
	// Note that GetTickCount() is inacurate. Steps have
	// spikes at 32 milliseconds when probing every 16 milliseconds.
	return hxdw_GetTimeTicksUs() / 1000;
}

/// Opens standard open file dialog box.
/// szDefaultFn - Optional. Initial file name path, or just directory.
/// szTitle     - Optional.
/// szExtFilter - Optional. File ext filter, if any. Eg. "*.EXE;*.DLL;*.BAT"
/// hwParent    - Optional. Parent window, eg. GetForegroundWindow().
std::string hxdw_OpenFileNameWithUI( const char* szDefaultFn, const char* szTitle, const char* szExtFilter, HWND hwParent )
{
	std::string srInitDir;
	char bfr[1024*4] = "";
	char bfrExtFltr[256] = "";
	if( szExtFilter && *szExtFilter ){
		//sprintf_s_( bfrExtFltr, sizeof(bfrExtFltr), "%s\0%s\0\0", szExtFilter, szExtFilter );
		// Below: inserts "%s\0%s\0\0" with percent-s-es replaced with 'szExtFilter'.
		size_t len = strlen(szExtFilter) + 1;
		if( (len*2 + 1) < sizeof(bfrExtFltr) ){
			memcpy( bfrExtFltr+len*0, szExtFilter, len );
			memcpy( bfrExtFltr+len*1, szExtFilter, len );
			memcpy( bfrExtFltr+len*2, "\0", 1 );
		}
	}
	if( szDefaultFn && *szDefaultFn ){
		if( hxdw_IsDir( szDefaultFn ) ){
			srInitDir = szDefaultFn;
		}else{
			auto dp2 = hxdw_SplitPath( szDefaultFn );
			srInitDir = dp2.first;
			snprintf( bfr, sizeof(bfr), "%s", dp2.second.c_str() );//sprintf_s
		}
	}
	OPENFILENAME ofn;
	memset( &ofn, 0, sizeof(ofn) );
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.Flags       |= OFN_NOVALIDATE;          // prevent disabling of front slashes.
	ofn.Flags       |= OFN_HIDEREADONLY;        // hide readonly flag.
	ofn.Flags       |= OFN_EXPLORER;            // use 'newer' explorer windows.
	ofn.Flags       |= OFN_ENABLESIZING;        // allow window to be resized.
	ofn.Flags       |= OFN_NOCHANGEDIR;         // prevent dialog for messing up the CWD.
	ofn.nMaxFile     = sizeof(bfr)-1;
	ofn.lpstrFile    = bfr;
	ofn.hwndOwner    = hwParent;//GetForegroundWindow();
	ofn.lpstrTitle   = szTitle;// "Open Executable File (XIEI)";
	ofn.lpstrFilter  = bfrExtFltr;
	ofn.lpstrInitialDir = srInitDir.c_str();
	if( GetOpenFileName( &ofn ) )
		return bfr;
	return "";
}

/// Internal Callback function for hxdw_BrowseForFolder()
INT CALLBACK hxdw_BFFCallbackProc( HWND hwnd, UINT uMsg, LPARAM lparam, LPARAM pData )
{
	if(lparam){}
	if( uMsg == BFFM_INITIALIZED )
		SendMessage( hwnd, BFFM_SETSELECTION, TRUE, pData );
	return 0;
}

#ifndef HXDW_NO_SHELL32_LIB

/// Shows Browse for folder Winapi window.
/// Returns the folder or an empty string if no folder was selected.
/// ref: https://www.arclab.com/en/kb/cppmfc/select-folder-shbrowseforfolder.html
///
/// hwParent = handle to parent window
/// title2 = text in dialog
/// folder2 = selected (default) folder
std::string hxdw_BrowseForFolder( HWND hwParent, std::string title2, std::string folder2 )
{
	BROWSEINFO brf;
	memset( &brf, 0, sizeof(BROWSEINFO) );
	brf.lpfn      = hxdw_BFFCallbackProc;
	brf.ulFlags   = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
	brf.hwndOwner = hwParent;
	brf.lpszTitle = title2.c_str();
	brf.lParam    = (LPARAM)folder2.c_str();

	LPITEMIDLIST pidl = 0;
	if( ( pidl = SHBrowseForFolder(&brf) ) ){
		char bfr[MAX_PATH] = "";
		//shlobj.h//shell32
		if( SHGetPathFromIDList( pidl, bfr ) ){
			return bfr;
		}
	}
	return "";
}

#endif //HXDW_NO_SHELL32_LIB

std::string hxdw_StrToLower( std::string inp )
{
	std::string::iterator a;
	for( a = inp.begin(); a != inp.end(); ++a ){
		if( *a >= 'A' && *a <= 'Z' ){
			*a += 'a' - 'A';
		}
	}
	return inp;
}
/*
std::string hxdw_StrToLower( const std::string& inp, int len )
{
	std::string outp;
	std::string::const_iterator ir2 = inp.begin();
	for( ; ir2 != inp.end(); ++ir2 ){
		char ch2 = *ir2;
		ch2 = ( ch2 >= 'A' && ch2 <= 'Z' ? (ch2 + ('a'-'A')) : ch2 );
		outp += ch2;
	}
	return outp;
}//*/

std::string hxdw_StrTruncate( std::string inp, int maxlen, const std::string dots2 )
{
	if( maxlen < (int)inp.size() ){
		inp.resize( maxlen );
		if( !dots2.empty() && inp.size() > dots2.size() ){
			inp = inp.substr( 0, inp.size() - dots2.size() );
			inp += dots2;
		}
	}
	return inp;
}
std::string hxdw_StrLTruncate( std::string inp, int maxlen, const std::string dots2 )
{
	if( maxlen < (int)inp.size() ){
		//inp.resize( maxlen );
		inp = inp.substr( inp.size() - maxlen );
		if( !dots2.empty() && inp.size() > dots2.size() ){
			inp = dots2 + inp.substr( dots2.size() );
		}
	}
	return inp;
}
std::string hxdw_StrMidTruncate( std::string inp, int nMaxLen, const std::string dots3 )
{
	if( !(nMaxLen >= dots3.size()) || nMaxLen < 2 ){
		return "";
	}
	if( inp.size() > nMaxLen ){
		int nLeft  = nMaxLen / 2;
		int nRight = ( nMaxLen - nLeft - int( double( double( dots3.size() ) / 2.0 ) + 0.5 ) );
		nLeft -= int( dots3.size() / 2 );
		inp = (
			inp.substr( 0, nLeft ) +
			dots3 +
			inp.substr( (inp.size() - nRight), std::string::npos ) );
	}
	return inp;
}

/// String prints from formated.
/// Parameter placeholders: %s, %d and %a.
std::string
hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string outp;
	const char* sz2 = fmt, *sz3 = 0;
	//char bfr[256];
	for( const auto& a : args4 ){
		if( !(sz3 = strchr( sz2, '%' )) )
			break;
		if( !strchr( "ads", sz3[1] ) )
			break;
		outp.append( sz2, sz3-sz2 );
		sz2 = sz3 + 2;
		std::string arg;
		if( a.bStr ){
			arg = a.srVal;
		}else{
			//snprintf( bfr, sizeof(bfr), "%lld", a.nVal );//sprintf_s
			//arg = bfr;
			arg = std::to_string( a.nVal );
		}
		outp += arg;
	}
	outp.append( sz2 );
	return outp;
}
/**
	Copies batch of files specified by input array.
	\param inp - list of pairs. for each, 'first' is full path to
		   source, existsing file, while 'second' is only base name for
		   new file.
	\param szDstDir - destination directory name.
*/
bool hxdw_CopyFilesToDir( const std::vector<std::pair<std::string,std::string> >& inp, const char* szDstDir, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	for( const auto& a : inp ){
		std::string bn2 = hxdw_SplitPath(a.first.c_str()).second;
		std::string bn3 = a.second;
	//	std::string newfname = hxdw_StrPrintf("%s\\%s", {{szDstDir,0,},{bn3.c_str(),0,},} );
		std::string newfname = hxdw_StrPrintf("%s\\%s", {
			HxdwPrintAdp( std::string(szDstDir) ),
			HxdwPrintAdp( bn3),} );
		if( !CopyFile( a.first.c_str(), newfname.c_str(), 0 ) ){
			//err3 = hxdw_StrPrintf("Can't copy file '%s'.", {{bn2.c_str(),0,},} );
			err3 = hxdw_StrPrintf("Can't copy file '%s'.", { HxdwPrintAdp( bn2 ),} );
			return 0;
		}
	}
	return 1;
}
/// Returns value from GetBinaryType().
/// Doesn't work with DLLs, only EXEs.
/// Eg: SCS_32BIT_BINARY - win32/x86
///     SCS_64BIT_BINARY - win64/x64
DWORD hxdw_GetBinaryType( const std::string srFname )
{
	DWORD eType = (DWORD)-1;
	if( !GetBinaryTypeA( srFname.c_str(), &eType ) )
		return (DWORD)-1;
	return eType;
}
bool hxdw_PutFileContents( const std::string filename, const char* data2, int nNumBytes, const char* flags2 )
{
	const bool bAppend = std::strchr( flags2, 'a');
	nNumBytes = ( nNumBytes != -1 ? nNumBytes : std::strlen(data2) );
	FILE* fp2 = std::fopen( filename.c_str(), ( bAppend ? "a+b" : "w+b") );
	if(!fp2)
		return 0;
	std::fwrite( data2, 1, nNumBytes, fp2 );
	std::fclose(fp2);
	fp2 = 0;
	return 1;
}
/// Joins path parts.
/// Input extension must be without leading dot character.
std::string
hxdw_PathJoin( const std::string& dir2, const std::string& basename2, const std::string& ext2 )
{
	std::string z;
	z = hxdw_StrPrintf("%s%s%s%s%s", {
				{ dir2,},
				{ (!dir2.empty() ? "\\" : ""),},
				{ basename2,},
				{ (!ext2.empty() ? "." : ""),},
				{ ext2,},
				});
	return z;
}
bool
hxdw_DeleteFilesWithRollback( const std::vector<std::string> filenames, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srTmstp;
	{
		uint64_t ts2 = ( hxdw_GetPosixTimeUs() / 1000 );
		//char bfr[64];
		//snprintf( bfr, sizeof(bfr), "%llu", ts2 );//sprintf_s
		//srTmstp = bfr;
		srTmstp = std::to_string(ts2);
	}
	std::vector<std::string> renamed2;
	for( const auto& fn2 : filenames ){
		auto dparts  = hxdw_SplitPath( fn2 );
		auto bparts  = hxdw_SplitExt( dparts.second );
		auto bn4     = hxdw_StrPrintf("%s_tmp%s", {{bparts.first,},{srTmstp,},} );
		auto frename = hxdw_PathJoin( dparts.first, bn4, bparts.second );
		if( hxdw_FileExists( frename.c_str() ) ){
			err3 = hxdw_StrPrintf("Cannot rename [%s] [3KxX2U]", {{frename,},} );
			return 0;
		}
		if( !MoveFile( fn2.c_str(), frename.c_str() ) ){
			err3 = hxdw_StrPrintf("Temporary move file failed [%s] [sO281M]", {{fn2,},} );
			return 0;
		}
		renamed2.push_back(frename);
	}
	for( const auto& fn2 : renamed2 ){
		if( !DeleteFile( fn2.c_str() ) ){
			err3 = hxdw_StrPrintf("Delete file failed [%s] [wxHg0o]", {{fn2,},} );
			return 0;
		}
	}
	return 1;
}

std::string hxdw_GetModuleFileName( HMODULE hDll )
{
	char bfr[MAX_PATH*2] = "";
	GetModuleFileName( hDll, bfr, sizeof(bfr) );
	return bfr;
}

std::string hxdw_GetWindowText( HWND hwnd )
{
	char bfr[256] = "";
	GetWindowText( hwnd, bfr, sizeof(bfr) );
	return bfr;
}

#ifndef HXDW_NO_GDI32_LIB

bool hxdw_GetWindowPixels( HWND hwnd,
		std::function<bool( const RGBQUAD* pPixels2, int w, int h )> calb6 )
{
	HWND hDesktopWnd = GetDesktopWindow();
	assert(hwnd);
	assert(hDesktopWnd);
	//int nScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	//int nScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	RECT rct;
	GetWindowRect( hwnd, &rct );
	int ww2 = rct.right - rct.left;
	int hh2 = rct.bottom - rct.top;

	HDC hDesktopDC = GetDC(hDesktopWnd);
	HDC hCaptureDC = CreateCompatibleDC(hDesktopDC);
	HBITMAP hCaptureBitmap = CreateCompatibleBitmap( hDesktopDC, ww2, hh2 );
	SelectObject(hCaptureDC, hCaptureBitmap);
	//BitBlt() -> gdi32.lib
	BitBlt( hCaptureDC, 0, 0, ww2, hh2,
				hDesktopDC, rct.left, rct.top, SRCCOPY|CAPTUREBLT);
	BITMAPINFO bmi;
	memset( &bmi, 0, sizeof(bmi) );
	bmi.bmiHeader.biSize = sizeof(bmi.bmiHeader);
	bmi.bmiHeader.biWidth = ww2;// nScreenWidth;
	bmi.bmiHeader.biHeight = hh2;// nScreenHeight;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD *pPixels = new RGBQUAD[ww2 * hh2];
	GetDIBits(
		hCaptureDC,
		hCaptureBitmap,
		0,
		hh2,//nScreenHeight,
		pPixels,
		&bmi,
		DIB_RGB_COLORS
	);
	std::shared_ptr<void> raii2( 0, [&](void*){
		if(pPixels)
			delete [] pPixels;
		if(hDesktopDC)
			ReleaseDC(hDesktopWnd, hDesktopDC);
		if(hCaptureDC)
			DeleteDC(hCaptureDC);
		if(hCaptureBitmap)
			DeleteObject(hCaptureBitmap);
	});
	bool rs2 = calb6( pPixels, ww2, hh2 );
	return rs2;
}

/**
	Captures desktop or window screenshot to image file.
	Captured output image format is PAM.
	\param hwnd - window to capture or 0, see 'flgs' parameter.
	\param flgs - character flags:
					w: capture active window (hwnd must be 0),
					s: capture screen (hwnd must be 0).

	References:
	* How to read the screen pixels
	  https://stackoverflow.com/questions/2659932/how-to-read-the-screen-pixels

	* Various methods for capturing the screen - CodeProject
	  https://www.codeproject.com/Articles/5051/Various-methods-for-capturing-the-screen

	* PAM Format
	- http://netpbm.sourceforge.net/doc/pam.html
	- https://en.wikipedia.org/wiki/Netpbm
*/
bool hxdw_CaptureWindowScreenToFile( const char* filename, HWND hwnd, const char* flgs )
{
	const bool bFrgWindow = !!strchr( flgs, 'w');
	const bool bCapScreen = !!strchr( flgs, 's');
	HWND hDesktopWnd = GetDesktopWindow();
	assert(hDesktopWnd);
	hwnd = ( hwnd ? hwnd : (bFrgWindow ? GetForegroundWindow() : (
			bCapScreen ? hDesktopWnd : 0 ) ) );
	if( !hwnd )
		return 0;
	const char* hdr2 =
		"P7\n""WIDTH %d\n""HEIGHT %d\n""DEPTH 3\n""MAXVAL 255\n""TUPLTYPE RGB\n"
		"ENDHDR\n";
	char bfr2[256];
	FILE* fpx = fopen(filename, "wb");
	if(!fpx){
		return 0;
	}
	hxdw_GetWindowPixels( hwnd, [&]( const RGBQUAD* pPixels2, int ww2, int hh2 )->bool{
		snprintf( bfr2, sizeof(bfr2), hdr2, ww2, hh2 );
		int len = strlen(bfr2);
		fwrite( bfr2, len, 1, fpx );
		for( int y = 0; y < hh2; y++ ){
			for( int x = 0; x < ww2; x++ ){
				int p = (hh2-y-1)*ww2+x;
				uint8_t r = pPixels2[p].rgbRed;
				uint8_t g = pPixels2[p].rgbGreen;
				uint8_t b = pPixels2[p].rgbBlue;
				uint8_t bfrRgb[3] = {r,g,b,};
				fwrite( bfrRgb, sizeof(bfrRgb), 1, fpx );
			}
		}
		return 1;
	});
	fclose(fpx);
	return 1;
}

#endif //HXDW_NO_GDI32_LIB

std::string
hxdw_StrReplace( std::string str, const std::string& from2, const std::string& to2 )
{
    size_t start_pos = 0;
    while( ( start_pos = str.find( from2, start_pos ) ) != std::string::npos ){
        str.replace( start_pos, from2.length(), to2 );
        start_pos += to2.length(); // Handles case where 'to2' is a substring of 'from2'
    }
    return str;
}

/**
	Retrieves dir contents given input dir.
	\param szFlags - see hxdw_GetDirFilesRcv().
	\param calb4 - callback function for each file or directory.
	               parameter falgs_ contains attributes, eg. HXDW_FA_Dir.
	               Return 1 to continue, 0 to stop all, 2 to stop current dir.
*/
bool hxdw_EnumDirFilesRcv( const char* szDir, const char* szFlags,
					std::function<short( const char* szFname, int falgs_ )> calb4 )
{
	std::string srDir = std::string(szDir) + "\\*";
	const bool bRcv     = !!strchr( szFlags, 'r' );
	const bool bDirs    = !!strchr( szFlags, 'd' );
	const bool bFiles   = !!strchr( szFlags, 'f' );
	const bool bDSuff   = !!strchr( szFlags, 's' );
	const bool bNoDSlnk = !!strchr( szFlags, 'y' );
	const bool bDSFolow =  !strchr( szFlags, 'v' );
	const int HXDW_WIN32_SYMLINK = 0x400;
	WIN32_FIND_DATA wfd;
	memset( &wfd, 0, sizeof(wfd) );
	HANDLE hFnd = FindFirstFile( srDir.c_str(), &wfd );
	if( !hFnd || hFnd == INVALID_HANDLE_VALUE ){
		return 1;
	}
	std::shared_ptr<void> ptr( 0, [&]( void* ){
			if(hFnd){ FindClose(hFnd); hFnd = 0; }
	});
	for( bool rs2 = !!hFnd; rs2; rs2 = FindNextFile( hFnd, &wfd ) ){
		const DWORD dwFa = wfd.dwFileAttributes;
		const bool bDir      = !!( dwFa & FILE_ATTRIBUTE_DIRECTORY );
		const bool bSymlink2 = ( dwFa & HXDW_WIN32_SYMLINK );
		const std::string bn2 = wfd.cFileName;
		const std::string fn2 = szDir + std::string("\\") + bn2;
		const int flags4 = (
				( bDir ? HXDW_FA_Dir : 0 ) ||
				( dwFa & HXDW_WIN32_SYMLINK ? HXDW_FA_Symlink : 0 ) );

		if( bn2 == ".." || bn2 == "." )
			continue;
		if( bDir && bNoDSlnk ){
			// FILE_ATTRIBUTE_REPARSE_POINT 1024 (0x400)
			// ref: https://docs.microsoft.com/en-us/windows/win32/fileio/file-attribute-constants
			if( dwFa & HXDW_WIN32_SYMLINK )
				continue;
		}
		if( ( bDir && bDirs ) || ( !bDir && bFiles ) ){
			std::string fn3 = ( (bDSuff && bDir) ?  (fn2 + "\\") : fn2 );
			short rs3 = calb4( fn3.c_str(), flags4 );
			if( !rs3 )
				return 0;
			if( rs3 == 2 )
				break;
		}
		if( bDir && bRcv && ( !bSymlink2||bDSFolow ) ){
			if( !hxdw_EnumDirFilesRcv( fn2.c_str(), szFlags, calb4 ) )
				return 0;
		}
	}
	return 1;
}
/**
	Retrieves dir contents given input dir.
	\param szFlags - string flags:
			f: get files, d: get dirs, r: recursive to subdirs.
			s: mark every dir with trailing slash/backslash.
			y: skip directory symbolic links.
			v: dir symlink no follow. like 'y' but reports symlink dirs, does not iterates their contents.
*/
bool hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>* fnames,
					const char* szFlags )
{
	return hxdw_EnumDirFilesRcv( szDir, szFlags, [&]( const char* szFname, int )->short{
		fnames->push_back( szFname );
		return 1;
	} );
}
/// Converts to C-string.
/// \sa hxdw_StrUtf8aToWcs().
/// ref: https://mariusbancila.ro/blog/2008/10/20/writing-utf-8-files-in-c/
std::string hxdw_StrWcsToUtf8a( const wchar_t* inp, int len )
{
	len = ( len != -1 ? len : wcslen( inp ) );
	int nChars = WideCharToMultiByte(
		CP_UTF8, 0, inp, len, 0, 0, 0, 0 );
	if( nChars == 0 )
		return "";
	std::string outp;
	outp.resize( nChars );
	WideCharToMultiByte(
		CP_UTF8, 0, inp, len, &outp[0], nChars, 0, 0 );
	return outp;
}
/// Converts to WCHAR string.
/// \sa hxdw_StrWcsToUtf8a().
/// ref: Win32  convert between wchar and utf8
/// -    https://gist.github.com/xebecnan/6d070c93fb69f40c3673#file-win32_utf8-c-L12
std::wstring hxdw_StrUtf8aToWcs( const char* inp, int len )
{
	len = ( len != -1 ? len : lstrlen( inp ) );
	int len2 = MultiByteToWideChar( CP_UTF8, 0, inp, len, 0, 0 );
	std::wstring outp2;
	outp2.resize( len2 );
	MultiByteToWideChar( CP_UTF8, 0, inp, len, &outp2[0], len2 );
	return outp2;
}
/// Struct used internally by hxdw_GetJuncPointW() with DeviceIoControl() function
/// with FSCTL_GET_REPARSE_POINT type.
/// It's direct copy from Winapi web pages.
/// * REPARSE_DATA_BUFFER (ntifs.h) - Windows drivers
/// - https://docs.microsoft.com/en-us/windows-hardware/drivers/ddi/content/ntifs/ns-ntifs-_reparse_data_buffer
typedef struct HXDW_REPARSE_DATA_BUFFER_ {
  ULONG  ReparseTag;
  USHORT ReparseDataLength;
  USHORT Reserved;
  union {
    struct {
      USHORT SubstituteNameOffset;
      USHORT SubstituteNameLength;
      USHORT PrintNameOffset;
      USHORT PrintNameLength;
      ULONG  Flags;
      WCHAR  PathBuffer[1];
    } SymbolicLinkReparseBuffer;
    struct {
      USHORT SubstituteNameOffset;
      USHORT SubstituteNameLength;
      USHORT PrintNameOffset;
      USHORT PrintNameLength;
      WCHAR  PathBuffer[1];
    } MountPointReparseBuffer;
    struct {
      UCHAR DataBuffer[1];
    } GenericReparseBuffer;
  };
} HXDW_REPARSE_DATA_BUFFER, *HXDW_PREPARSE_DATA_BUFFER;

/**
	Retrieves path stored in synlink, which can be relative.
	Works like its POSIX equivalent, readlink().
	Can be used with file and directory symbolic links.

	Taken from project: libntlink.
	URL: https://github.com/LRN/libntlink
	Original description follows.

	* GetJuncPointW:
	* @path1: a pointer to variable (pointer to wchar_t) to receive result
	* @path2: full directory path (UTF-16)
	* @relative: set to 1 if the path is relative. Always 0 for junction points.
	* @linktype: set to 1 if the link is a symlink. 0 if a junction
	*
	* Retrieves target directory for junction point @path2, allocates a buffer
	* for it and writes a pointer to that buffer into @path1
	*
	* @path2 must exist.
	* @path2 must be a junction point.
	* For junction points:
	*   String in @path1 will be in unparseable form - with \??\ prefix
	*   (i.e. \??\C:\Windows) - and without a trailing slash.
	* For symlinks:
	*   String in @path1 will be in normal form.
	* If the function fails, *@path1 remains unmodified.
	* Free @path1 with free() when it is no longer needed.
	*
	* Returns:
	* 0  - success
	* -1 - failed to open @path2
	* -2 - failed to get junction
	* -3 - failed to allocate memory
	*
*/
int hxdw_GetJuncPointW( wchar_t** path1, const wchar_t* path2, int* relative, int* linktype )
{
	HANDLE dir_handle;
	BOOL ret;
	HXDW_REPARSE_DATA_BUFFER *rep_buf;
	size_t len1 = 0;//, len2;
	DWORD returned_bytes;
	BYTE returned_data[MAXIMUM_REPARSE_DATA_BUFFER_SIZE];
	//len2 = wcslen (path2);

	dir_handle = CreateFileW( path2, GENERIC_READ | GENERIC_WRITE,
			0, NULL, OPEN_EXISTING,
			FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, 0 );
	if( dir_handle == INVALID_HANDLE_VALUE ){
		return -1;
	}
	ret = DeviceIoControl( dir_handle, FSCTL_GET_REPARSE_POINT, NULL, 0, returned_data, 1024, &returned_bytes, NULL );
	CloseHandle (dir_handle);
	if( ret == 0 ){
		return -2;
	}
	rep_buf = (HXDW_REPARSE_DATA_BUFFER*) returned_data;
	if (rep_buf->ReparseTag == IO_REPARSE_TAG_SYMLINK){
		len1 = rep_buf->SymbolicLinkReparseBuffer.SubstituteNameLength;
		*path1 = (wchar_t*)malloc( len1 + sizeof (wchar_t) );
		if (*path1 == NULL){
			return -3;
		}
		if (relative)
			*relative = (rep_buf->SymbolicLinkReparseBuffer.Flags & 0x0001) != 0;
		if (linktype)
			*linktype = 1;
		memcpy( *path1, &((BYTE *) rep_buf->SymbolicLinkReparseBuffer.PathBuffer)
			[rep_buf->SymbolicLinkReparseBuffer.SubstituteNameOffset], len1 );

	}else if (rep_buf->ReparseTag == IO_REPARSE_TAG_MOUNT_POINT){

		len1 = rep_buf->MountPointReparseBuffer.SubstituteNameLength;
		*path1 = (wchar_t*)malloc(len1 + sizeof (wchar_t));
		if( *path1 == NULL ){
			return -3;
		}
		if (relative)
			*relative = 0;
		if (linktype)
			*linktype = 0;
		memcpy (*path1, &((BYTE *) rep_buf->MountPointReparseBuffer.PathBuffer)
				[rep_buf->MountPointReparseBuffer.SubstituteNameOffset], len1);
	}
	(*path1)[len1 / sizeof (wchar_t)] = 0;
	return 0;
}
/**
	Reads value of symbolic link.

	Ref:
	* readlink(2)  read value of symbolic link - Linux man page
	  https://linux.die.net/man/2/readlink
*/
std::string hxdw_ReadLink( const std::string pathname, bool* bIsRelative )
{
	wchar_t* path2 = 0;
	int relative2 = 0;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if(path2){ free(path2); path2 = 0; }
	});
	std::wstring pathname2 = hxdw_StrUtf8aToWcs( pathname.c_str(), -1 );
	DWORD attr2 = GetFileAttributesW( pathname2.c_str() );
	if( !(attr2 & 0x400) )   // 0x400: WIN32 SYMLINK
		return "";
	if( hxdw_GetJuncPointW( &path2, pathname2.c_str(), &relative2, 0 ) )
		return "";
	if(bIsRelative)
		*bIsRelative = !!relative2;
	std::string outp = hxdw_StrWcsToUtf8a( path2, -1 );
	return outp;
}
/// Returns module handle given C-address inside it.
/// \sa hxdw_GetModuleFileNameFromAddr
HMODULE hxdw_GetModuleHandleFromAddr( const void* addr )
{
	HMODULE hDll = 0;
	GetModuleHandleExA( GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
				reinterpret_cast<LPCSTR>(addr), &hDll );
	return hDll;
}
/// Returns module file name given C-address inside it.
/// \param addr - C-address inside the module|DLL, typically address of the 'DllMain' function.
std::string hxdw_GetModuleFileNameFromAddr( const void* addr )
{
	HMODULE hDll = 0;
	GetModuleHandleExA( GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
				reinterpret_cast<LPCSTR>(addr), &hDll );
	if( hDll && hDll != INVALID_HANDLE_VALUE ){
		return hxdw_GetModuleFileName( hDll );
	}
	return "";
}

// UINT SendInput(UINT cInputs,LPINPUT pInputs,int cbSize);
// https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-sendinput
bool hxdw_SendKeyboardInput( const std::vector< std::pair<int,int> >& aKeys, const char* flags2 )
{
	bool bUp       = !!strchr( flags2, 'u');
	bool bPost     = !!strchr( flags2, 'p');
	bool bScanCode = !!strchr( flags2, 's');
	std::vector<INPUT> iinputs2;
	if( bPost ){
		for( const auto& a : aKeys ){
			UINT uMsg2      = ( bUp ? WM_KEYUP : WM_KEYDOWN );
			int nVirtKey    = a.first;
			LPARAM lKeyData = 1; // 0-15 Specifies the repeat count. ...
			HWND hwnd = GetForegroundWindow();
			PostMessage( hwnd, uMsg2, (WPARAM)nVirtKey, lKeyData );
		}
	}else{
		for( const auto& a : aKeys ){
			INPUT in2;
			memset( &in2, 0, sizeof(in2) );
			in2.type       = INPUT_KEYBOARD;
			in2.ki.dwFlags = ( bUp ? KEYEVENTF_KEYUP : 0 );
			in2.ki.wVk     = (WORD)a.first;
			if(bScanCode){
				in2.ki.wScan    = (WORD)MapVirtualKey( a.first, MAPVK_VK_TO_VSC );
				in2.ki.dwFlags |= KEYEVENTF_SCANCODE;
			}
			in2.mi.dwExtraInfo = GetMessageExtraInfo();
			iinputs2.push_back(in2);
		}
	}
	bool bOk = !!SendInput( (UINT)iinputs2.size(), &iinputs2[0], sizeof(INPUT) );
	return bOk;
}

bool hxdw_SendMouseDeltaInput( std::pair<int,int> xyDelta )
{
	INPUT in2;
	memset( &in2, 0, sizeof(in2) );
	in2.type       = INPUT_MOUSE;//INPUT_KEYBOARD
	in2.mi.dwFlags = MOUSEEVENTF_MOVE;//|MOUSEEVENTF_ABSOLUTE|0;
	in2.mi.time    = 0; //GetTickCount();
	in2.mi.dx      = xyDelta.first;
	in2.mi.dy      = xyDelta.second;
	in2.mi.dwExtraInfo = GetMessageExtraInfo();
	bool bOk = !!SendInput( 1, &in2, sizeof(INPUT) );
	return bOk;
}
/**
	Sends mouse buttons using SendInput() Winapi.
	Each element of input 'aMButtons' must be set to mouse button
	flag, eg. MOUSEEVENTF_LEFTDOWN or MOUSEEVENTF_LEFTUP.
	Input is received by the window that is under the cursor on the screen.
	Eg.:
		hxdw_SendMouseButtonInput( {{MOUSEEVENTF_LEFTDOWN,0,},} );
*/
bool
hxdw_SendMouseButtonInput( const std::vector< std::pair<int,int> >& aMButtons )
{
	std::vector<INPUT> iinputs2;
	for( const auto& a : aMButtons ){
	//	auto b = std::find_if( mbtns.begin(), mbtns.end(),
	//			[&]( const std::pair< int, std::pair<int,int> >& b ){
	//					return a.first == b.first;
	//	});
		int nMButtonFlag = a.first;
		INPUT in2;
		memset( &in2, 0, sizeof(in2) );
		in2.type           = INPUT_MOUSE;
		in2.mi.dwFlags     = nMButtonFlag;// eg. MOUSEEVENTF_MOVE
		in2.mi.time        = 0; //GetTickCount();
		in2.mi.dwExtraInfo = GetMessageExtraInfo();
		iinputs2.push_back( in2 );
	}
	bool bOk = !!SendInput( (UINT)iinputs2.size(), &iinputs2[0], (UINT)sizeof(INPUT) );
	return bOk;
}
/// Send mouse wheel input.
/// \param nWheelDelta - 1-based amount of wheel input.
///                      can be negative.
///                      Fe. value 1 moves mouse wheel forward, -1 moves mouse wheel backward.
bool hxdw_SendMouseWheelInput( int nWheelDelta )
{
	INPUT in2;
	memset( &in2, 0, sizeof(in2) );
	in2.type         = INPUT_MOUSE;  //INPUT_KEYBOARD
	in2.mi.dwFlags   = MOUSEEVENTF_WHEEL;  //MOUSEEVENTF_MOVE//MOUSEEVENTF_ABSOLUTE|0;
	in2.mi.mouseData = nWheelDelta * WHEEL_DELTA;  //WHEEL_DELTA=120;
	in2.mi.time      = 0; //GetTickCount();
	//in2.mi.dx        = xyDelta.first;
	//in2.mi.dy        = xyDelta.second;
	in2.mi.dwExtraInfo = GetMessageExtraInfo();
	bool bOk = !!SendInput( 1, &in2, sizeof(INPUT) );
	return bOk;
}

/**
	Retrieves final path of the symlink.
	I.e. gets symbolic link target as full path.

	References:

	     GetFinalPathNameByHandle()
	-    https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlea
	-    How do I get information about the target of a symbolic link?
	-    https://devblogs.microsoft.com/oldnewthing/20100212-00/?p=14963

		* Use GetFinalPathNameByHandle to resolve a symbolic link to a local directory
		- https://stackoverflow.com/a/50182947

		DWORD GetFinalPathNameByHandleA(
			HANDLE hFile,LPSTR  lpszFilePath,DWORD  cchFilePath,DWORD  dwFlags);

		// GetFileInformationByHandleEx()
		//GetFinalPathNameByHandleA( hFile, bfr, sizeof(bfr), FILE_NAME_NORMALIZED );

		// GetFinalPathNameByHandleA( file, path, MAX_PATH, FILE_NAME_NORMALIZED );

		//#include <filesystem>
		/std::filesystem::read_symlink("");
*/
std::string hxdw_GetSymlinkFullPath( const std::string pathname )
{
	using GFPNBHW_t = DWORD WINAPI( HANDLE hFile, LPWSTR lpszFilePath, DWORD cchFilePath, DWORD dwFlags );
	std::wstring pathname2 = hxdw_StrUtf8aToWcs( pathname.c_str(), -1 );
	//const bool pathname = 0;
	DWORD attr2 = GetFileAttributesW( pathname2.c_str() );
	if( !(attr2 & 0x400) )   // 0x400: WIN32 SYMLINK
		return "";

	static GFPNBHW_t* fnGetFinPthNBHW = 0;
	if(!fnGetFinPthNBHW){
		HMODULE hDll2 = GetModuleHandleA("kernel32");
		fnGetFinPthNBHW = ( !hDll2 ? 0 : (GFPNBHW_t*)GetProcAddress( hDll2, "GetFinalPathNameByHandleW" ) );
	}
	HANDLE hFile = 0;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( hFile && hFile != INVALID_HANDLE_VALUE ){
			CloseHandle(hFile);
			hFile = 0;
		}
	});
	if(!fnGetFinPthNBHW)
		return "";
	// FILE_FLAG_OPEN_REPARSE_POINT - does not fail if tartget file does not exists.
	// ref: https://stackoverflow.com/a/46383996
	hFile = CreateFileW( pathname2.c_str(),
        GENERIC_READ,  //GENERIC_READ or 0.
        0, 0, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS,  //FILE_FLAG_OPEN_REPARSE_POINT,
        0 );
	if( !hFile || hFile == INVALID_HANDLE_VALUE )
		return "";

	DWORD dwRet; //GetFinalPathNameByHandle(), GetFinalPathNameByHandleW().
	dwRet = fnGetFinPthNBHW( hFile, 0, 0,
			FILE_NAME_NORMALIZED | VOLUME_NAME_DOS );
	if( !dwRet )
		return "";
	std::wstring bfr2;
	bfr2.resize( dwRet );
	dwRet = fnGetFinPthNBHW( hFile, &bfr2[0], bfr2.size(),
			FILE_NAME_NORMALIZED | VOLUME_NAME_DOS );
	bfr2[dwRet] = L'\0';
	std::string outp = hxdw_StrWcsToUtf8a( bfr2.c_str(), -1 );

	// Replace "\\?\UNC\" with "\\".
	// Replace "\\?\" with "".
	// ref: https://stackoverflow.com/a/52861283
	if( (outp.size() >= 4) && (outp.substr( 0, 4 ) == "\\\\?\\") )
		outp = outp.substr( 4 );
	if( (outp.size() >= 8) && (outp.substr( 0, 8 ) == "\\\\?\\UNC\\") )
		outp = "\\\\" + outp.substr( 8 );
	return outp;
}
/// Creates filesystem new directory.
/// Recursive subdirectories are created if needed.
/// \sa hxdw_IsDir()
bool hxdw_MkdirRcv( std::string srDirPathName )
{
	// int SHCreateDirectoryExA( HWND hwnd, LPCSTR pszPath, const SECURITY_ATTRIBUTES *psa );
	// https://docs.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shcreatedirectoryexa
	// - 248 characters max.
	// auto dir2 = hxdw_StrUtf8aToWcs( srDirPathName.c_str(), -1 );
	// int res2 = SHCreateDirectoryExW( 0, dir2.c_str(), 0 );
	std::string srCurPath;
	auto lmbEachSubPath = [&]( std::function<bool( const std::string& )> calb2 )->void{
		std::vector<std::string> parts2;
		hxdw_StrExplode( srDirPathName.c_str(), parts2, {"\\","/",}, -1, "\\/" );
		for( const auto& a : parts2 ){
			if( !srCurPath.empty() )
				srCurPath += "/";
			srCurPath += a;
			if(!calb2( srCurPath ))
				return;
		}
	};
	std::vector<std::string> aDirsCreating;
	bool bExistsAsFile = 0;
	lmbEachSubPath( [&]( const std::string& pth )->bool{
		if( !hxdw_IsDir( pth.c_str() ) ){
			if( hxdw_FileExists( pth.c_str() ) ){
				bExistsAsFile = 1;
				return 0;
			}
			aDirsCreating.push_back( pth );
		}
		return 1;
	});
	if( bExistsAsFile )
		return 0;
	for( const auto& a : aDirsCreating ){
		auto dir2 = hxdw_StrUtf8aToWcs( a.c_str(), -1 );
		if( !CreateDirectoryW( dir2.c_str(), 0 ) )
			return 0;
	}
	return 1;
}
//GetFileAttributes()
// CreateSymbolicLink()
// - https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-createsymboliclinka
//   SYMBOLIC_LINK_FLAG_DIRECTORY - 0x1, The link target is a directory.
//
//BOOLEAN CreateSymbolicLinkW( LPCWSTR lpSymlinkFileName, LPCWSTR lpTargetFileName, DWORD dwFlags );
// https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-createsymboliclinkw
/**
	Creates symbolic link (symlink), to file or to directory.
	\param srSymlinkFileName - file name to create.
	\param srTarget          - target symlink points to. file does not need to exist.
	\param flags2            - character flags:
                               d: create directory symlink (instead of file symlink).
*/
bool hxdw_Mklink( std::string srSymlinkFileName, std::string srTarget, std::string flags2 )
{
	using CrSymlinkW_t = BOOLEAN( LPCWSTR lpSymlinkFileName, LPCWSTR lpTargetFileName, DWORD dwFlags );
	static CrSymlinkW_t* fnCrSymlinkW = 0;
	if( !fnCrSymlinkW ){
		HMODULE hDll2 = GetModuleHandleA("kernel32");
		fnCrSymlinkW = ( !hDll2 ? 0 : (CrSymlinkW_t*)GetProcAddress( hDll2, "CreateSymbolicLinkW" ) );
	}
	if( fnCrSymlinkW ){
		std::wstring aaa, bbb;
		aaa = hxdw_StrUtf8aToWcs( srSymlinkFileName.c_str(), -1 );
		bbb = hxdw_StrUtf8aToWcs( srTarget.c_str(), -1 );
		const int WIN32_SYMLINK_DIR = 0x1; //SYMBOLIC_LINK_FLAG_DIRECTORY=0x1
		const DWORD dwFlags = ( std::strchr(flags2.c_str(),'d') ? WIN32_SYMLINK_DIR : 0 );
		//CreateSymbolicLinkW( srSymlinkFileName.c_str(), srTarget.c_str(), 0x0 );
		bool rs2 = !!fnCrSymlinkW( aaa.c_str(), bbb.c_str(), dwFlags );
		return rs2;
	}
	return 0;
}


void HxPrintfBase::printData( const std::string& inp )
{
	printf("%s", inp.c_str() );
}

void HxPrintfBase::convFmtToArr( const char* fmt3, std::vector<std::string>& fmts4 )
{
	const char* sz2 = fmt3, *anchor2 = fmt3;
	for( ; (sz2 = std::strstr(sz2,"%")) && sz2[1]; ){
		if( sz2[1] == '%' ){
			sz2 += 2;
		}else{
			fmts4.push_back( std::string( anchor2, sz2-anchor2 ) );
			anchor2 = sz2;
			sz2 += 1;
		}
	}
	fmts4.push_back( anchor2 );
}

/// Sets global log-level used by HxPrintfBase::operator() member functions.
/// The higher global loglevel, the more messages get logged.
/// Messages are being logged via calls to HxPrintfBase::operator() functions.
/// Unless changed by this function, default global log-level is 4.
/// F.e. global log-level 4 means that all log-calls with level 0-4 (inclusivelly)
/// will be logged, while all other omited.
void HxPrintfBase::setGlobalLogLevel( uint32_t llevel ) //static
{
	LGlobalLevel = llevel;
}
/*
	Start process with elevation request.

	https://stackoverflow.com/a/6418873
	ShellExecute( NULL,
		"runas",
		"c:\\windows\\notepad.exe",
		" c:\\temp\\report.txt",
		NULL,                        // default dir
		SW_SHOWNORMAL
	);

	CreateProcessAsUserA()
	CreateProcessWithLogonW()
*/

#ifndef HXDW_NO_ADVAPI32_LIB

/// Checks if current process has the administrative rights - is elevated.
/// Ref:
/// 	How to check if a process has the administrative rights
/// 	https://stackoverflow.com/a/8196291
///
bool hxdw_IsCurrentProcessElevated()
{
	bool ok2 = 0;
	HANDLE hToken = 0;
	// OpenProcessToken() -> "advapi32.lib"
	if( OpenProcessToken( GetCurrentProcess(), TOKEN_QUERY, &hToken ) ){
		TOKEN_ELEVATION aElevation;
		DWORD cbSize = sizeof(TOKEN_ELEVATION);
		bool ok3 = !!GetTokenInformation( hToken, TokenElevation,
				&aElevation, sizeof(aElevation), &cbSize );
		ok2 = ( !ok3 ? 0 : !!aElevation.TokenIsElevated );
	}
	if( hToken )
		CloseHandle( hToken );
	return ok2;
}

#endif //HXDW_NO_ADVAPI32_LIB

/// Returns the last Win32 error, in string format.
/// Returns an empty string if there is no error.
/// ref: https://stackoverflow.com/a/17387176
std::string hxdw_GetLastError()
{
	DWORD errorMessageID = GetLastError();   // Get the error message, if any.
	if( !errorMessageID ){
		return "";   // No error message has been recorded
	}
	LPSTR messageBuffer = nullptr;
	size_t size2 = FormatMessageA(
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			nullptr, errorMessageID, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPSTR)&messageBuffer, 0, nullptr );
	std::string message2( messageBuffer, size2 );

	LocalFree(messageBuffer);   // Free the buffer.
	//message2 = hf_trim_stdstring<char>( message2.c_str(), "\r\n\x20" );
	message2 = hxdw_TrimStr( message2.c_str(), "\r\n\x20", "LR", -1 );
	return message2;
}
/**
	Loads dynamic library module to remote process given PID and DLL-file-name.
	Uses OpenProcess() and CreateRemoteThread() method.

	\param szDllFileName - name of DLL file location. either full or relative path.
				if is with no path part, it is merged with
				the current directory.

	Ref:
		* API Hooking with MS Detours.
		- - https://www.codeproject.com/Articles/30140/API-Hooking-with-MS-Detours#Remote
		* Dll injection for api hooks, incl. SetWindowsHookEx().
		- - https://www.apriorit.com/dev-blog/679-windows-dll-injection-for-api-hooks
*/
bool hxdw_LoadRemoteProcessDll( DWORD pid2, const char* szDllFileName,
		std::string* err_, const char* flags2 )
{
	flags2 = ( flags2 ? flags2 : "" );
	std::string err3, *err2 = ( err_ ? err_ : &err3 );
	HANDLE hProcess = 0;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( hProcess ){
			CloseHandle(hProcess);
			hProcess = 0;
		}
	});
	char bfrDllPath[MAX_PATH] = {0,};
	if( std::strpbrk( szDllFileName, "\\/") ){
		std::snprintf( bfrDllPath, sizeof(bfrDllPath), "%s", szDllFileName );
	}else{
		char DirPath[MAX_PATH] = {0,};
		GetCurrentDirectory( sizeof(DirPath), DirPath );
		//std::snprintf( bfrDllPath, sizeof(DirPath), "%s\\%s", DirPath, szDllFileName );
		std::snprintf( bfrDllPath, sizeof(bfrDllPath), "%s\\%s", DirPath, szDllFileName );
	}
	if( !hxdw_FileExists( bfrDllPath ) ){
		*err2 = "Path to the DLL file not found [vTMkBu]";
		return 0;
	}
	const bool bAllOPAccess = !!std::strchr( flags2, 'a');
	// Note: the query-information flag for OpenProcess() seems not always required,
	//       eg. required fpr RE4-UHD but not for MGS-MC.
	const DWORD dwDesiredAccess = ( bAllOPAccess ? PROCESS_ALL_ACCESS :  (
			PROCESS_CREATE_THREAD|PROCESS_VM_OPERATION|
			PROCESS_VM_READ|PROCESS_VM_WRITE|
			PROCESS_QUERY_INFORMATION ) );
	hProcess = OpenProcess( dwDesiredAccess, FALSE, pid2 );
	if( !hProcess ){
		*err2 = hxdw_GetLastError();
		return 0;
	}
	LPVOID LoadLibraryAddr = (LPVOID)GetProcAddress( GetModuleHandle("kernel32.dll"), "LoadLibraryA");
	if( !LoadLibraryAddr ){
		*err2 = hxdw_StrPrintf("Failed getting proc address [ph04Th]", {});
		return 0;
	}
	const LPVOID LLParam = (LPVOID) VirtualAllocEx( hProcess, NULL, std::strlen(bfrDllPath)+1,
				MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE );
				//PAGE_EXECUTE,PAGE_EXECUTE_READWRITE
	if( !LLParam ){
		*err2 = hxdw_StrPrintf("VirtualAllocEx() failed [%a] [WzUOT0]", { hxdw_GetLastError(),});
		return 0;
	}
	bool rs2;
	rs2 = !!WriteProcessMemory( hProcess, LLParam, bfrDllPath, std::strlen(bfrDllPath)+1, NULL );
	if( !rs2 ){
		*err2 = hxdw_StrPrintf("WriteProcessMemory() failed [%a] [Tx5rCo]",
			{ hxdw_GetLastError(),});
		return 0;
	}
	rs2 = !!CreateRemoteThread(
				hProcess, NULL, NULL,
				(LPTHREAD_START_ROUTINE)LoadLibraryAddr,
				LLParam,
				NULL,
				NULL );
	if( !rs2 ){
		*err2 = hxdw_StrPrintf("Create Remote Thread failed [%a] [96EFNt]", {
					hxdw_GetLastError(),});
		return 0;
	}
	return 1;
}

/// Test keys down.
/// Omits values in the input list that are set to zero.
/// \param flags2 - Text flags.
///                        'o' - retutns true if any key in the input list is down.
///                        'm' - modkeys part of all keys passed are not exclusive.
///                        'a' - use GetAsyncKeyState() over GetKeyState().
///                        'b' - use 0x8000 bit on ret-val from key state Winapis.
bool hxdw_TestKeysDown( const std::vector<int32_t>& keylist, const char* flags2 )
{
	const bool bAny             = !!std::strchr( flags2, 'o' );
	const bool bNotModExclusive = !!std::strchr( flags2, 'm' );
	const bool bUseAsync        = !!std::strchr( flags2, 'a' );
	const bool bUseLastBit      = !!std::strchr( flags2, 'b' );
	if( keylist.empty() ){
		return 0;
	}
	{
		auto a = std::find_if( keylist.begin(), keylist.end(), []( int key2 )->bool{return !!key2;} );
		if( a == keylist.end() ){  //if all input keys are set to 0.
			return 0;
		}
	}
	// VK_MENU = ALT-key
	std::vector<int32_t> aStdModKeys = { VK_SHIFT, VK_CONTROL, VK_MENU, VK_LWIN, VK_RWIN,};
	auto key3 = keylist.begin();
	for( ; key3 != keylist.end(); ++key3 ){
		if( !(*key3) ){
			continue;
		}
		{
			auto irK = std::find( aStdModKeys.begin(), aStdModKeys.end(), *key3 );
			if( irK != aStdModKeys.end() ){
				// this key is a modkey - clear it from the standard hotkey list.
				*irK = 0;
			}
		}
		//if( *irB != nVirtKey || (lKeyData & (1<<30)) )
		//const SHORT nState = GetKeyState( *key3 );//GetAsyncKeyState
		SHORT nState = ( bUseAsync ? GetAsyncKeyState(*key3) : GetKeyState( *key3 ) );
		//printf("k:%4d, nState: 0x%X\n", *key3, (uint32_t)nState );
		nState = ( bUseLastBit ? nState & 0x8000 : nState );
		if( nState ){
			if( bAny ){
				return 1;
			}
		}else{
			if( !bAny ){
				return 0;
			}
		}
	}
	if( key3 == keylist.end() ){
		if( !bNotModExclusive ){
			auto modkey = aStdModKeys.begin();
			for( ; modkey != aStdModKeys.end(); ++modkey ){
				if( *modkey ){
					//const SHORT nState2 = GetAsyncKeyState( *modkey );
					//const SHORT nState2 = GetKeyState( *modkey );
					SHORT nState2 = ( bUseAsync ? GetAsyncKeyState(*modkey) : GetKeyState( *modkey ) );
					nState2 = ( bUseLastBit ? nState2 & 0x8000 : nState2 );
					if( nState2 ){
						return 0;
					}
				}
			}
		}
		return 1;
	}
	return 0;
}
/// Returns Current executable file path. Dir + file name + ext.
/// Can be called from code inside EXE or DLL.
/// ref: https://stackoverflow.com/a/20614656
std::string hxdw_GetCurrentExecutableFilePath()
{
	char anExePath[ MAX_PATH * 2 ];
	anExePath[0] = 0;
	DWORD len = GetModuleFileName( nullptr, anExePath, sizeof(anExePath)-1 );
	if( !len ){
		return "";
	}
	return anExePath;
}
std::string hxdw_GetCurrentDirectory()
{
	char dmy0[1] = "";
	const DWORD num2 = GetCurrentDirectory( 0, dmy0 );
	if( !num2 )
		return "";
	std::vector<char> bfr2;
	bfr2.resize( num2, 0 );
	const DWORD num3 = GetCurrentDirectory( num2, &bfr2[0] );
	assert( num2 >= num3 );  //returned val does not count nul-char.
	assert( bfr2[bfr2.size() - 1] == '\0' );
	std::string outp;
	outp.assign( &bfr2[0] );
	return outp;
}
/// Checks if it is a main window in the application.
/// flags2: 'o' - may be obscured (uses Winapi IsWindowVisible()).
bool hxdw_IsMainWindow( HWND hwnd, const char* flags2 )
{
	bool bObscured = !!std::strchr( flags2, 'o' );
	return ( !GetWindow( hwnd, GW_OWNER ) && (bObscured || IsWindowVisible( hwnd )) );
}
HWND hxdw_FindMainWindowGivenPID( DWORD process_id, const char* flags2 )
{
	// flags2: 'o' - may be obscured.
	process_id = ( process_id ? process_id : GetCurrentProcessId() );
	struct handle_data{
		DWORD process_id;
		HWND window_handle;
		const char* flags2;
	};
	auto enum_windows_callback = []( HWND handle, LPARAM lParam )->BOOL{
		handle_data& data2 = *(handle_data*)lParam;
		DWORD process_id = 0;
		GetWindowThreadProcessId( handle, &process_id );
		if( data2.process_id != process_id || !hxdw_IsMainWindow( handle, data2.flags2 ) )
			return 1;
		data2.window_handle = handle;
		return 0;
	};
    handle_data data2;
    data2.process_id = process_id;
    data2.window_handle = 0;
    data2.flags2 = flags2;
    EnumWindows( enum_windows_callback, (LPARAM)&data2 );
    return data2.window_handle;
}
/**
	Checks if c-string ends with another c-string.
	\code
		// Example:
		hxdw_EndsWith( filename, -1, ".tar.gz", -1, "i");
	\endcode
*/
bool hxdw_EndsWith( const char* sz2, int len2, const char* sz3, int len3, const char* flags2 )
{
	len2 = ( len2 != -1 ? len2 : std::strlen(sz2) );
	len3 = ( len3 != -1 ? len3 : std::strlen(sz3) );
	if( len3 > len2 ){
		return 0;
	}
	return !hxdw_StrCmpOpt( (sz2+len2)-len3, sz3, -1, flags2 );
}
double hxdw_StrToDbl( const char* inp, char** endp )
{
	char* endp2, **endp3 = ( endp ? endp : &endp2 );
	double retv = 0.0;
	//if( !hxdw_StrCmpOpt( inp, "0x", -1, "i") ){}
	if( inp[0] && !hxdw_StrCmpOpt( inp, "0x", 2, "i") ){
		retv = (double) std::strtoimax( inp, endp3, 16 );
	}else{
		retv = std::strtod( inp, endp3 );
	}
	return retv;
}
std::string hxdw_HexEncode( const void* data_, size_t uDataSize, const char* flags2 )
{
	std::string outp;
	const bool bSpaceSep = std::strchr( flags2, 's');
	char bfr2[32];
	const uint8_t* data2 = reinterpret_cast<const uint8_t*>(data_);
	const uint8_t* endd = data2 + uDataSize;
	for( ; data2 < endd; data2++ ){
		if( bSpaceSep && data2 > data_ ){ //if not first.
			outp += "\x20";
		}
		snprintf( bfr2, sizeof(bfr2), "%02X", static_cast<uint32_t>(*data2) );
		outp += bfr2;
	}
	return outp;
}
std::vector<uint8_t> hxdw_HexDecode( const char* szData2, int len_ )
{
	std::vector<uint8_t> outp;
	const size_t len2 = ( len_ != -1 ? (size_t)len_ : std::strlen(szData2) );
	auto lmbAsciiToNum = []( int chr )->int{
		return ( chr >= 'a' && chr <= 'f' ?
					(chr - 'a') + 10 : (
				chr >= 'A' && chr <= 'F' ?
					(chr - 'A') + 10 : (
				chr >= '0' && chr <= '9' ?
					chr - '0' : (
				-1 ))));
	};
	for( size_t ii2 = 0; ii2 < len2; ){
		if( szData2[ii2] <=  0x20 ){   //skip any whitespaces.
			ii2 += 1;
			continue;
		}
		//assert( ii2+1 < len2 );
		//assert( szData2[ii2+1] > 0x20 );
		if( ii2+1 == len2 ){
			assert(!"Hex decode: ERROR: unexpected end of input string. Expected second character for byte decode [w7RkmF]");
		}
		if( szData2[ii2+1] <= 0x20 ){
			assert(!"Hex decode: ERROR: non-hexadec character in byte sequence [lB2lh7]");
		}
		const char ch2 = szData2[ii2+0];
		const char ch3 = szData2[ii2+1];
		const int h = lmbAsciiToNum( ch2 );
		const int l = lmbAsciiToNum( ch3 );
		if( l < 0 || h < 0 ){
			assert(!"Hex decode: ERROR: non-hexadec character encountered [4J3cQ2]");
		}
		uint8_t uByte = 0;
		uByte += static_cast<uint8_t>( l );
		uByte += static_cast<uint8_t>( h ) * 16;
		outp.push_back( uByte );
		ii2 += 2;
	}
	return outp;
}
/// Prints text to stdout aka. STD_OUTPUT_HANDLE on win32.
bool hxdw_StdPrint2( const char* msg2 )
{
	//flags2 = flags2 ? flags2 : "";
	//const bool bAddNl = !!std::strchr( flags2, 'n');
	std::string sr2 = msg2;
	//if( bAddNl ){
	//	sr2 += "\n";
	//}
	HANDLE hStdo2 = GetStdHandle( STD_OUTPUT_HANDLE );
	assert( hStdo2 != INVALID_HANDLE_VALUE );
	DWORD dmy0;
	WriteFile( hStdo2, sr2.c_str(), sr2.size(), &dmy0, nullptr );
	return 1;
}
std::array<int,2> hxdw_GetWindowSize( HWND hwnd )
{
	RECT rc2 = {0,0,0,0,};
	//GetClientRect( hwnd, &rc2 );
	//return { rc2.right, rc2.bottom,};
	GetWindowRect( hwnd, &rc2 );
	return { rc2.right - rc2.left, rc2.bottom - rc2.top,};
}
/**
	Gets the wall clock time aka. local time.
	\code
		SYSTEMTIME lt = hxdw_GetWallClockTime();
		printf("The wall clock time is: %02d:%02d\n", lt.wHour, lt.wMinute);

		SYSTEMTIME st;
		GetSystemTime(&st);
		printf("The system time is: %02d:%02d\n", st.wHour, st.wMinute);
	\endcode
*/
SYSTEMTIME hxdw_GetWallClockTime()
{
	SYSTEMTIME ltm;
	ZeroMemory( &ltm, sizeof(ltm) );
	GetLocalTime( &ltm );
	return ltm;
}
/// Gets the current system date and time in Coordinated Universal Time (UTC) format.
/// \sa hxdw_GetWallClockTime().
SYSTEMTIME hxdw_GetSystemTime()
{
	SYSTEMTIME stm;
	ZeroMemory( &stm, sizeof(stm) );
	GetSystemTime( &stm );
	return stm;
}

HICON hxdw_GetWindowIcon( HWND hWnd )
{
	HICON hIcon;
	hIcon = (HICON)SendMessage(hWnd, WM_GETICON, ICON_SMALL, NULL);
	if(hIcon){
		return hIcon;
	}
	hIcon = (HICON)GetClassLongPtr(hWnd, GCLP_HICONSM);
	if(hIcon){
		return hIcon;
	}
	hIcon = (HICON)SendMessage(hWnd, WM_GETICON, ICON_BIG, NULL);
	if(hIcon){
		return hIcon;
	}
	hIcon = (HICON)GetClassLongPtr(hWnd, GCLP_HICON);
	if(hIcon){
		return hIcon;
	}
	return hIcon;
}
HxdwSizeAdp::HxdwSizeAdp( uint64_t uSize_ ) : uSize(uSize_)
{
	assert( uSize );
}
HxdwSizeAdp::HxdwSizeAdp( float placeholder_ ) : bUnlimited(1L)
{
	assert( placeholder_ == 0.f );
}
// Enumerates current desktop windows.
// flags2: 'm' - Get main window list only. ie. skip child-windows.
//         'o' - May be obscured (only valid if 'm' present).
//         'z' - Get window list in z-order. If this flag is not present, uses EnumWindows() Winapi.
//         'p' - Handles the cases such as when the window has the browse-for-file dialog open.
//               Used is call to ''GetWindow(hwnd2,GW_ENABLEDPOPUP)'' and if successful, returned handle replaces the original.
//
// Ref: Iterating over all desktop windows in C++, by z-order
//      https://gist.github.com/blewert/b6e7b11c565cf82e7d700c609f22d023
//
bool hxdw_EnumWindows( std::function<bool(HWND)> calb3, const char* flags2 )
{
	struct handle_data2{
		bool bMainOnly, bObscured, bEnbldPopup;
		std::function<bool(HWND)> calb4;
	};
	const bool bByZOrder = !!std::strchr( flags2, 'z');

	handle_data2 data2;
	data2.bMainOnly     = !!std::strchr( flags2, 'm');
	data2.bObscured     = !!std::strchr( flags2, 'o');
	data2.bEnbldPopup   = !!std::strchr( flags2, 'p');
	data2.calb4         = calb3;
	auto enum_windows_callback2 = []( HWND hwnd2, LPARAM lParam )->BOOL{
		handle_data2& data2 = *(handle_data2*)lParam;
		bool bOk = 1L;
		if( data2.bMainOnly ){
			bOk = hxdw_IsMainWindow( hwnd2, (data2.bObscured ? "o": "") );
		}
		if( bOk && data2.bEnbldPopup ){
			const HWND hw2 = GetWindow( hwnd2, GW_ENABLEDPOPUP );
			hwnd2 = ( hw2 ? hw2 : hwnd2 );
		}
		if( bOk && !data2.calb4( hwnd2 ) ){
			return 0L;
		}
		return 1L;
	};
	if( !bByZOrder ){
		return !!EnumWindows( enum_windows_callback2, (LPARAM)&data2 );
	}else{
		HWND hwnd3 = GetTopWindow(GetDesktopWindow());
		// // find the window with the lowest Z-order value (GW_HWNDLAST not GW_HWNDFIRST)
		// hwnd3 = GetWindow( hwnd3, GW_HWNDLAST );
		do{
			if( !enum_windows_callback2( hwnd3, (LPARAM)&data2 ) ){
				return 1L;
			}
		}while( hwnd3 = GetWindow( hwnd3, GW_HWNDNEXT ) );
		return 1L;
	}
}
/// Returns the size of window decoration, ie. anything that is
/// not in the window clien area.
/// Returned values are all >= 0.
/// Returned are two arrays, first contains size of decoration at the left-upper corner
/// and second at the right-bottom.
std::array<std::array<int,2>,2>
hxdw_GetWindowDecorationSize( HWND hwnd )
{
	RECT rcWnd = {0,0,0,0,}, rcCli = {0,0,0,0,};
	GetWindowRect( hwnd, &rcWnd );
	GetClientRect( hwnd, &rcCli );
	MapWindowPoints( hwnd, HWND_DESKTOP, (POINT*)&rcCli, 2 );
	//MapWindowPoints( hwnd, HWND_DESKTOP, &((POINT*)(&rcCli))[0], 1 );
	//MapWindowPoints( hwnd, HWND_DESKTOP, &((POINT*)(&rcCli))[1], 1 );
	int nLeftMargin   = rcCli.left   - rcWnd.left;
	int nRightMargin  = rcWnd.right  - rcCli.right;
	int nTopMargin    = rcCli.top    - rcWnd.top;
	int nBottomMargin = rcWnd.bottom - rcCli.bottom;
	assert( nLeftMargin >= 0 );
	assert( nRightMargin >= 0 );
	assert( nTopMargin >= 0 );
	assert( nBottomMargin >= 0 );
	return {
		std::array<int,2>{ nLeftMargin, nTopMargin,},
		std::array<int,2>{ nRightMargin, nBottomMargin,},
	};
}
/// Sets windows position and|or size.
/// flags2 - if this param is empty, pos and size must be specified.
///          'p': specify pos in nXPos and nYPos.
///          's': specify size in nWidth and nHeight.
///          'c': indicates that pos and size is being set via window client area position.
bool hxdw_SetWindowPosSize( HWND hwnd, int nXPos, int nYPos,
		int nWidth, int nHeight, const char* flags2 )
{
	bool bPos = 1L, bSize = 1L, bByClienArea = 0L;
	if( flags2 && *flags2 ){
		bPos         = !!std::strchr( flags2, 'p');
		bSize        = !!std::strchr( flags2, 's');
		bByClienArea = !!std::strchr( flags2, 'c');
	}
	if(bByClienArea){
		assert( bPos || bSize );
	}
	LONG move2[4] = {0,0,0,0,}; //XYWH
	if(!bPos||!bSize){
		RECT rc2 = {0,0,0,0,};
		GetWindowRect( hwnd, &rc2 );
		move2[0] = rc2.left;
		move2[1] = rc2.top;
		move2[2] = rc2.right  - rc2.left;
		move2[3] = rc2.bottom - rc2.top;//*/
	}//*/
	if(bPos){
		move2[0] = nXPos;
		move2[1] = nYPos;
	}
	if(bSize){
		move2[2] = nWidth;
		move2[3] = nHeight;
	}
	if(bByClienArea){
		auto dcrn = hxdw_GetWindowDecorationSize( hwnd );
		if(bPos){
			move2[0] -= dcrn[0][0];  //X
			move2[1] -= dcrn[0][1];  //Y
		}
		if(bSize){
			move2[2] += dcrn[0][0] + dcrn[1][0];  //W
			move2[3] += dcrn[0][1] + dcrn[1][1];  //H
		}
	}
	//SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER
	SetWindowPos( hwnd, 0,
		move2[0], move2[1], move2[2], move2[3],
		SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER );
	return 1L;
}
/// Normalizes the device path, eg. returned by GetProcessImageFileName(),
/// and returns the filesystem path.
/// Input example:
///     "\\Device\\HarddiskVolume1\\testdir\\file_01.txt"
/// Output example:
///     "C:\\testdir\\file_01.txt"
/// In essence, beginning part "\\Device\\HarddiskVolume1" gets replaced with "C:".
///
/// REF: https://social.msdn.microsoft.com/Forums/en-US/c48bcfb3-5326-479b-8c95-81dc742292ab/windows-api-to-get-a-full-process-path?forum=vcgeneral
std::string hxdw_NormalizeNTPath( const char* inp )
{
	const std::string in2 = hxdw_StrReplace( std::string(inp), "/", "\\");
	const char* szFolders = in2.c_str();
	{
		if( in2.empty() || !in2[0] || in2[0] != '\\' ){
			return "";
		}
		// Successfully skip 3 backslash characters in the device path.
		for( size_t ii2 = 0; ii2 < 2; ii2++ ){ // for BS chars 2-3.
			szFolders = std::strchr( szFolders+1, '\\' );
			if( !szFolders ){
				return "";
			}
		}
		assert( in2.c_str() < szFolders );
		assert( szFolders[0] == '\\' );
	}
	std::string srSysDriveDevice; //eg. "\\Device\\HarddiskVolume2"
	srSysDriveDevice.assign( in2.c_str(), szFolders-in2.c_str() );

	char letter3[3] = {0,':',0,};
	for( char letter2 = 'A'; letter2 <= 'Z'; letter2++ ){
		letter3[0] = letter2;
		char bfr2[MAX_PATH] = "";
		bool rs2 = !!QueryDosDeviceA( letter3, bfr2, sizeof(bfr2) );   //QueryDosDevice()
		if( rs2 ){
			if( !hxdw_StrCmpOpt( srSysDriveDevice.c_str(), bfr2, -1, "i" ) ){
				//printf("[[MATCH]] [%s]\n", bfr2 );
				std::string outp;
				outp += letter3;
				outp += szFolders;
				return outp;
			}
		}
	}
	return "";
}
std::vector<std::string> hxdw_GetCommandLine2()
{
	std::vector<std::string> outp;
	{
		wchar_t* lpCmdLine = GetCommandLineW();  //GetCommandLine()
		int argc3 = 0; wchar_t** argv3;
		argv3 = CommandLineToArgvW( lpCmdLine, &argc3 );
		assert( argv3 );
		for( int ii2=0; ii2 < argc3; ii2++ ){
			std::string sr2;
			sr2 = hxdw_StrWcsToUtf8a( argv3[ii2], -1 );
			outp.push_back( sr2 );
		}
	}
	return outp;
}
std::vector<const char*>
hxdw_GetCommandLine3( std::vector<std::string>* outp )
{
	assert( outp );
	std::vector<const char*> aAsCPointers;
	*outp = hxdw_GetCommandLine2();
	for( auto ir2 = outp->begin(); ir2 != outp->end(); ++ir2 ){
		aAsCPointers.push_back( ir2->c_str() );
	}
	return aAsCPointers;
}



/**
	Converts up to four RGBA color components given string into UINT32 value.
	Uses 2 format parameters, one is for input string and other for bit layout.
	\param fmt4 - color format of the input string.
	              eg. "rgba" for "128,0,8,255".
	              eg. "rgb-" for "128,0,8".
	\param fmt0x - color format for the output UINT32 value.
	    Color components are layed out according to letters in the format using
	    right shift operator.
	    Format string must start with the "0x" and contain sequences of valid collor letters.
	    Additionally, "00" may be used to specify omited component, its value set to 0.
	    eg. "0xAARRGGBB" for "128,0,8,255" -> 0xFF800011
	    eg. "0x00RRGGBB" for "128,0,17"    -> 0x00800011

*/
uint32_t hxdw_ConvColorStrFmtToRGBFmt( const char* inp, const char* fmt4, const char* fmt0x )
{
	{
		assert( inp && *inp );
		assert( fmt4 );
		size_t len3 = std::strlen( fmt4 );
		assert( len3 == 4 );
		size_t len2 = std::strlen( fmt0x ); // eg. "0xAARRGGBB"
		assert( len2 == 10 );
	}
	int aARGBShifts[4] = {-1,-1,-1,-1,};
	{
		std::string srHead = std::string(fmt0x).substr(0,2);
		assert( srHead == "0x" && "Parameter must begin with 0x character squence [C8KtVlj]" );
		fmt0x = &fmt0x[2];
		const char* pLetter = std::strchr("ARGB0", fmt0x[2] );
		assert( pLetter && "0x must be followed by the color code letter [zFCLwDK]" );
		//
		const char* pAA = std::strstr( fmt0x, "AA" );
		const char* pRR = std::strstr( fmt0x, "RR" );
		const char* pGG = std::strstr( fmt0x, "GG" );
		const char* pBB = std::strstr( fmt0x, "BB" );
		assert( pAA || pRR || pGG || pBB );
		const char* ptrs2[4] = { pAA, pRR, pGG, pBB,};
		for( int ii3=0; ii3 < 4; ii3++ ){
			const int idx2 = int(ptrs2[ii3] - fmt0x);
			assert( idx2 % 2 == 0 );
			if( ptrs2[ii3] ){
				aARGBShifts[ii3] = std::abs( (idx2 / 2) - 3 );
			}else{
				aARGBShifts[ii3] = -1;
			}
		}
	}
	std::vector<std::string> aRgb3;  //eg. from "64,99,0"
	hxdw_StrExplode( inp, aRgb3, {",",}, -1, "\x20\t", "");
	if( aRgb3.size() < 4 ){
		aRgb3.resize( 4, "0");
	}
	uint32_t uColor = 0;
	for( size_t ii2 = 0; ii2 < 4; ii2++ ){
		if(0){
		}else if( fmt4[ii2] == 'a' ){
			assert( aARGBShifts[0] != -1 );
			uColor |= (uint32_t(atoi( aRgb3[ii2].c_str() )) << (aARGBShifts[0]*8));
		}else if( fmt4[ii2] == 'r' ){
			assert( aARGBShifts[1] != -1 );
			uColor |= (uint32_t(atoi( aRgb3[ii2].c_str() )) << (aARGBShifts[1]*8));
		}else if( fmt4[ii2] == 'g' ){
			assert( aARGBShifts[2] != -1 );
			uColor |= (uint32_t(atoi( aRgb3[ii2].c_str() )) << (aARGBShifts[2]*8));
		}else if( fmt4[ii2] == 'b' ){
			assert( aARGBShifts[3] != -1 );
			uColor |= (uint32_t(atoi( aRgb3[ii2].c_str() )) << (aARGBShifts[3]*8));
		}
	}
	return uColor;
}

HANDLE hxdw_CreateThreadSimple( std::function<uint32_t()> calb2, uint32_t uDelayMs )
{
	struct ThrParams_t{
		std::function<uint32_t()> calb3;
		uint32_t uDelayMs;
	};
	ThrParams_t* sThrParams = new ThrParams_t;
	sThrParams->calb3    = calb2;
	sThrParams->uDelayMs = uDelayMs;

	HANDLE hThr = 0;
	hThr = CreateThread( 0, 0, []( void* user2 )->DWORD{
		ThrParams_t* pParams = static_cast<ThrParams_t*>( user2 );
		assert( pParams );
		ThrParams_t sPrms = *pParams;
		delete pParams;
		pParams = 0;
		if( sPrms.uDelayMs ){
			Sleep( sPrms.uDelayMs );
		}
		uint32_t rs2 = sPrms.calb3();
		return rs2;
	}, sThrParams, 0, 0 );
	return hThr;
}

const std::vector<std::pair<std::vector<int32_t>,std::vector<int32_t>>>&
hxdw_GetModKeyToVirtKeyMap()
{
	// MOD_ALT=0x0001, MOD_CONTROL=0x0002, MOD_SHIFT=0x0004, MOD_WIN=0x0008
	static const std::vector<std::pair<std::vector<int32_t>,std::vector<int32_t>>> aModToKeyMap = {
		{ {MOD_ALT,},     {VK_MENU,}, },
		{ {MOD_SHIFT,},   {VK_SHIFT,}, },
		{ {MOD_CONTROL,}, {VK_CONTROL,}, },
		{ {MOD_WIN,},     {VK_LWIN,VK_RWIN,}, },
	};
	return aModToKeyMap;
}
/// Given mod key code (eg. MOD_SHIFT) returns corresponding
/// virtual key code (eg. VK_SHIFT).
/// Returns value is the virtual-key-code.
/// Returns 0 on error, ie. if input in 'nModKey' is not an actual modkey.
int32_t hxdw_ConvModKeyToVirtKey( int32_t nModKey )
{
	auto map2 = hxdw_GetModKeyToVirtKeyMap();
	using ElType2_t = decltype( *map2.begin() );
	auto a = std::find_if( map2.begin(), map2.end(),
		[&]( const ElType2_t& a )->bool{
			assert( !a.first.empty() );
			//hxdw_Any( nModKey, a.first );
			bool bOk = std::any_of( a.first.begin(), a.first.end(),
				[&](int32_t a)->bool{return a == nModKey;} );
			return bOk;
		} );
	if( a != map2.end() ){
		assert( !a->second.empty() );
		return *a->second.begin();
	}
	return 0;
}
std::vector<int32_t>
hxdw_ConvModKeysToVirtKeyList( int32_t nModKeyAsFlags, const char* flags2 )
{
	std::vector<int32_t> outp;
	if( nModKeyAsFlags & MOD_ALT ){
		outp.push_back( VK_MENU );
	}
	if( nModKeyAsFlags & MOD_CONTROL ){
		outp.push_back( VK_CONTROL );
	}
	if( nModKeyAsFlags & MOD_SHIFT ){
		outp.push_back( VK_SHIFT );
	}
	if( nModKeyAsFlags & MOD_WIN ){
		bool bLWin = std::strchr( flags2, 'l' );
		bool bRWin = std::strchr( flags2, 'r' );
		bLWin = ( (!bRWin && !bLWin) ? 1L : 0L );
		if( bLWin ){
			outp.push_back( VK_LWIN );
		}
		if( bRWin ){
			outp.push_back( VK_RWIN );
		}
	}
	return outp;
}
/// Reverse of hxdw_ConvModKeyToVirtKey() function.
int32_t hxdw_ConvVirtKeyToModKey( int32_t nVirtKey )
{
	auto map2 = hxdw_GetModKeyToVirtKeyMap();
	using ElType3_t = decltype( *map2.begin() );
	auto a = std::find_if( map2.begin(), map2.end(),
		[&]( const ElType3_t& a )->bool{
			assert( !a.second.empty() );
			bool bOk = std::any_of( a.second.begin(), a.second.end(),
				[&](int32_t a)->bool{return a == nVirtKey;} );
			return bOk;
		} );
	if( a != map2.end() ){
		assert( !a->first.empty() );
		return *a->first.begin();
	}
	return 0;
}
bool hxdw_IsVirtKeyAlsoModKey( int32_t nVirtKey )
{
	return !!hxdw_ConvVirtKeyToModKey( nVirtKey );
}

/// Possibly case insensitive string compare version of std::strcmp().
/// Only english alphabet letters considered in CI option.
/// Motivation: No c-locale dependency on CI compare.
/// \param flags2 - flags as c-string.
///                 'i' - turns on CI comparision.
///                 'z' - treats input character sequences as c-strings.
///                       the 'num' parameter must be set to 0.
/// \return Returns 0 if both strings are equal.
///         Returns value less than 0 if first is smaller.
int hxdw_StrCmpOpt3( const char* a, const char* b, size_t num, const char* flags2 )
{
	bool bCi = 0L, bNullTerm = 0L;
	if( flags2 ){
		bCi       = !!std::strchr( flags2, 'i');
		bNullTerm = !!std::strchr( flags2, 'z');
	}
	if( bNullTerm ){
		assert( !num && "[m3fd9H]");
		num = 0;
		num--;  //wrap the unsigned to its max value.
	}
	for( ; *a && *b && num; ++a, ++b, --num ){
		if( *a != *b ){
			if(bCi){
				char ch2 = *a, ch3 = *b;
				ch2 = ( ch2 >= 'a' && ch2 <= 'z' ? (ch2 - ('a'-'A')) : ch2 );
				ch3 = ( ch3 >= 'a' && ch3 <= 'z' ? (ch3 - ('a'-'A')) : ch3 );
				if( ch2 != ch3 ){
					break;
				}
			}else{
				break;
			}
		}
	}
	return ( !num ? 0 : ( static_cast<int>( *a ) - static_cast<int>( *b ) ) );
}
const char* hxdw_StrSearch2( const char* inp, size_t len2, const char* needle2, size_t len4, const char* flags2 )
{
	len2 = ( len2 == size_t(-1) ? std::strlen(inp)     : len2 );
	len4 = ( len4 == size_t(-1) ? std::strlen(needle2) : len4 );
	const bool bCi = std::strchr( flags2, 'i');
	for( size_t ii2=0; ii2 + len4 <= len2; ii2++ ){
		if( !hxdw_StrCmpOpt3( &inp[ii2], needle2, len4, (bCi?"i":"") ) )
			return &inp[ii2];
	}
	return 0;
}
const char* hxdw_StrSearch3( const char* inp, const char* end_, const char* needle2, const char* flags2 )
{
	assert( inp && end_ && inp <= end_ );
	size_t len2 = end_ - inp;
	return hxdw_StrSearch2( inp, len2, needle2, -1, flags2 );
}
/**
	Returns current compilation date formated as string of three numbers.
	Internally parses the '__DATE__' preprocessor macro.
	Intended as replacement for the '__DATE__' macro.
	Eg.: If current date is "Feb 12 2023", returns "2023-02-12".
*/
std::string hxdw_GetDateAtCompileTime( const char* flags2 )
{
	static const std::vector<std::string> aMonths = {
			"Jan","Feb","Mar","Apr","May","Jun","Jul",
			"Aug","Sep","Oct","Nov","Dec",};
	// __DATE__ macro. Eg.: "Feb 12 1996" or "Apr 1 2015".
	const char* szDate2 = __DATE__;
	//const char* szDate2 = "  Feb  1  1996 ";
	std::vector<std::string> parts2;
	hxdw_StrExplode( szDate2, parts2, {"\x20",}, -1, "", "e" );
	assert( parts2.size() >= 3 );
	auto a = std::find_if( aMonths.begin(), aMonths.end(),
		[&]( const std::string& s )->bool{
			return parts2[0] == s;
		});
	int dst2 = std::distance( aMonths.begin(), a );
	assert( dst2 >= 0 );
	char bfr2[64];
	std::snprintf( bfr2, sizeof(bfr2), "%04d-%02d-%02d",
				atoi( parts2[2].c_str() ),
				dst2 + 1,
				atoi( parts2[1].c_str() ) );
	return bfr2;
}
/// Gets windows position and size.
/// flags2 - Flags as c-string.
///          'c': indicates that pos and size to retrieve is of the window client area.
///          'm': indicates that pos to retrieve is of the window middle position.
/// Returned are two arrays, first is position and second is size.
/// \sa hxdw_SetWindowPosSize()
std::array<std::array<int,2>,2>
hxdw_GetWindowPosSize( HWND hwnd, const char* flags2 )
{
	const bool bGetClientArea = !!std::strchr( flags2, 'c');
	const bool bGetMidPoint   = !!std::strchr( flags2, 'm');
	std::array<std::array<int,2>,2> outp;
	RECT rc2 = {0,0,0,0,};
	GetWindowRect( hwnd, &rc2 );
	int ww2 = rc2.right - rc2.left;
	int hh2 = rc2.bottom - rc2.top;
	outp[0][0] = rc2.left;
	outp[0][1] = rc2.top;
	outp[1][0] = ww2;
	outp[1][1] = hh2;
	if( bGetClientArea ){
		auto res2 = hxdw_GetWindowDecorationSize( hwnd );
		outp[0][0] += res2[0][0];
		outp[0][1] += res2[0][1];
		int cx2 = res2[1][0] + res2[0][0];
		int cy2 = res2[1][1] + res2[0][1];
		assert( outp[1][0] >= cx2 );
		assert( outp[1][1] >= cy2 );
		outp[1][0] -= cx2;
		outp[1][1] -= cy2;
	}
	if( bGetMidPoint ){
		outp[0][0] += outp[1][0] / 2;
		outp[0][1] += outp[1][1] / 2;
	}
	return outp;
}
std::array<int,2> hxdw_GetIconDimensions( HICON hIcon3 )
{
	if( !hIcon3 ){
		return {0,0,};
	}
	ICONINFO ici2;   //GetSystemMetrics
	std::memset( &ici2, 0, sizeof(ici2) );
	bool rs2 = !!GetIconInfo( hIcon3, &ici2 );
	assert( rs2 );
	//
	BITMAP sbmp;
	std::memset( &sbmp, 0, sizeof(sbmp) );
	GetObject( ici2.hbmMask, sizeof(sbmp), &sbmp );
	//printf("WxH: %d*%d\n", (int)sbmp.bmWidth, (int)sbmp.bmHeight );
	return { sbmp.bmWidth, sbmp.bmHeight,};
}
/**
	Loads icon from file.
	Intended to be of the same functionality as LoadIcon().
	REF: "https://mattfife.com/?p=494".
	\param szIconFileName - eg. ".\\MyIcon.ico".

	Use winapi DestroyIcon() to free the returned icon handle.
*/
HICON hxdw_LoadIconFromFile( const char* szIconFileName, size_t dmy0 )
{
	assert( !dmy0 );
	UINT icon_flags = LR_LOADFROMFILE | LR_DEFAULTSIZE;
	HICON hIcon = (HICON) LoadImage( nullptr, szIconFileName, IMAGE_ICON, 0, 0, icon_flags );
	return hIcon;
}
